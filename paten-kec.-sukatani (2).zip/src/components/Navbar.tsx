import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  ShieldCheck, 
  LogOut, 
  Clock, 
  RotateCw, 
  Cloud, 
  RefreshCw, 
  WifiOff, 
  Menu,
  Check 
} from 'lucide-react';
import { UserLevel } from '../types';

interface NavbarProps {
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar }) => {
  const { 
    currentUser, 
    logout, 
    sessionSecondsLeft, 
    extendSession,
    cloudSyncStatus,
    isOnline,
    lastSyncTime,
    isMigrating,
    forceCloudSync
  } = useApp();

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const getRoleLabel = (level: UserLevel, seksi?: string) => {
    switch (level) {
      case 'L1': return 'Admin';
      case 'L2': return 'Yanlik';
      case 'L3': return 'Pemerintahan';
      case 'L4': return 'Ekbang';
      case 'L5': return 'PMD';
      case 'L6': return 'Trantib';
      default: return seksi || 'Petugas';
    }
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand */}
          <div className="flex items-center gap-3">
            {onToggleSidebar && (
              <button
                type="button"
                id="btn-toggle-mobile-sidebar"
                onClick={onToggleSidebar}
                className="lg:hidden p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
                title="Buka menu navigasi"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}
            <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 p-1 flex items-center justify-center shrink-0 shadow-xs">
              <img 
                src="/logo-kabupaten-bekasi.svg" 
                alt="Logo Kabupaten Bekasi" 
                className="w-full h-full object-contain"
                onError={(e) => {
                  e.currentTarget.src = '/logo-kabupaten-bekasi.png';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-slate-800 tracking-tight">
                  PATEN Kec. Sukatani
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-800">
                  Pelayanan Terpadu
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Pencatatan Pelayanan Satu Pintu Berbasis 6 Level Hak Akses
              </p>
            </div>
          </div>

          {/* Right Action & User Profile Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Cloud Database Sync Indicator */}
            <button 
              id="cloud-sync-indicator"
              type="button"
              disabled={isMigrating}
              onClick={() => forceCloudSync()}
              title={
                !isOnline 
                  ? 'Koneksi internet terputus. Data disimpan di offline cache lokal dan disinkronkan saat online.' 
                  : isMigrating || cloudSyncStatus === 'syncing'
                  ? 'Sedang menyinkronkan data dengan basis data daring cloud...'
                  : `Basis Data Daring Cloud Terhubung (Klik untuk sinkronkan manual. Terakhir: ${lastSyncTime || 'Baru saja'})`
              }
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-all cursor-pointer ${
                !isOnline 
                  ? 'bg-amber-50 text-amber-700 border-amber-200' 
                  : isMigrating || cloudSyncStatus === 'syncing'
                  ? 'bg-blue-50 text-blue-700 border-blue-200 animate-pulse'
                  : cloudSyncStatus === 'error'
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
              }`}
            >
              {!isOnline ? (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-600" />
                  <span className="hidden sm:inline">Offline</span>
                </>
              ) : isMigrating || cloudSyncStatus === 'syncing' ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-blue-600 animate-spin" />
                  <span className="hidden sm:inline">Sinkronisasi...</span>
                </>
              ) : (
                <>
                  <Cloud className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">Cloud Sinkron</span>
                  {lastSyncTime && (
                    <span className="text-[10px] text-emerald-600 hidden md:inline font-mono">
                      ({lastSyncTime})
                    </span>
                  )}
                </>
              )}
            </button>

            {/* Session Timeout Badge */}
            <div 
              title="Waktu sisa sesi aktif sebelum otomatis logout karena tidak ada aktivitas"
              className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-medium border ${
                sessionSecondsLeft < 120 
                  ? 'bg-red-50 text-red-700 border-red-200 animate-pulse' 
                  : 'bg-slate-100 text-slate-600 border-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>Sesi: {formatTimer(sessionSecondsLeft)}</span>
              <button 
                onClick={extendSession}
                title="Perpanjang durasi sesi aktif"
                className="hover:text-emerald-700 ml-1 p-0.5"
              >
                <RotateCw className="w-3 h-3" />
              </button>
            </div>

            {/* User Profile Identity Badge */}
            <div 
              id="user-profile-badge"
              className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50/80 text-left"
            >
              <div className="w-8 h-8 rounded-full bg-white border border-slate-300 flex items-center justify-center text-slate-700 font-semibold text-xs shadow-xs">
                {currentUser.level === 'L1' ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                ) : (
                  <User className="w-4 h-4 text-slate-600" />
                )}
              </div>
              <div className="text-left hidden sm:block">
                <div className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                  <span className="font-bold text-emerald-700">
                    {getRoleLabel(currentUser.level, currentUser.seksi)}
                  </span>
                  <span className="text-slate-400">•</span>
                  <span>{currentUser.name}</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  {currentUser.email}
                </div>
              </div>
            </div>

            {/* Direct Logout Button */}
            <button
              id="btn-logout"
              onClick={() => logout()}
              title="Keluar dari akun (Logout)"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-red-50 hover:text-red-700 text-slate-700 text-xs font-medium rounded-lg border border-slate-200 hover:border-red-200 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
