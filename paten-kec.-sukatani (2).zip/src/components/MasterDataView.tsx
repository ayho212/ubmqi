import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { JenisPelayanan, Desa, SeksiType } from '../types';
import { 
  Database, 
  Layers, 
  MapPin, 
  PlusCircle, 
  Trash2, 
  Edit3, 
  Save, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Hash, 
  FileText,
  Building,
  RotateCcw,
  Cloud,
  RefreshCw,
  Server,
  ShieldCheck,
  Check,
  Laptop
} from 'lucide-react';

export const MasterDataView: React.FC = () => {
  const { 
    jenisPelayananList, 
    desaList, 
    addJenisPelayanan, 
    updateJenisPelayanan, 
    deleteJenisPelayanan,
    addDesa,
    updateDesa,
    deleteDesa,
    isAdmin,
    users,
    records,
    cloudSyncStatus,
    isOnline,
    lastSyncTime,
    isMigrating,
    forceCloudSync
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'pelayanan' | 'desa' | 'cloud'>('pelayanan');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [migrationStatusMsg, setMigrationStatusMsg] = useState<string | null>(null);

  // Form State: Jenis Pelayanan
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [serviceSeksi, setServiceSeksi] = useState<SeksiType>('Yanlik');
  const [serviceKode, setServiceKode] = useState<string>('');
  const [serviceNama, setServiceNama] = useState<string>('');
  const [servicePersyaratan, setServicePersyaratan] = useState<string>('');

  // Form State: Desa
  const [editingDesaId, setEditingDesaId] = useState<string | null>(null);
  const [desaNama, setDesaNama] = useState<string>('');
  const [desaKode, setDesaKode] = useState<string>('');

  // Filter seksi in service table
  const [filterSeksi, setFilterSeksi] = useState<string>('ALL');

  if (!isAdmin) {
    return (
      <div className="bg-white rounded-xl p-8 border border-slate-200 text-center">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-slate-800">Akses Terbatas</h2>
        <p className="text-sm text-slate-500 mt-1">
          Halaman Master Data hanya dapat diakses oleh Administrator Level 1.
        </p>
      </div>
    );
  }

  // --- Handlers: Jenis Pelayanan ---
  const handleServiceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceKode.trim() || !serviceNama.trim()) {
      setNotification({ type: 'error', message: 'Kode dan Nama Pelayanan wajib diisi.' });
      return;
    }

    const persyArr = servicePersyaratan
      ? servicePersyaratan.split('\n').map(s => s.trim()).filter(Boolean)
      : [];

    if (editingServiceId) {
      updateJenisPelayanan(editingServiceId, {
        seksi: serviceSeksi,
        kode: serviceKode.trim().toUpperCase(),
        namaPelayanan: serviceNama.trim(),
        persyaratan: persyArr,
      });
      setNotification({ type: 'success', message: 'Jenis pelayanan berhasil diperbarui!' });
    } else {
      addJenisPelayanan({
        seksi: serviceSeksi,
        kode: serviceKode.trim().toUpperCase(),
        namaPelayanan: serviceNama.trim(),
        persyaratan: persyArr,
      });
      setNotification({ type: 'success', message: 'Jenis pelayanan baru berhasil ditambahkan!' });
    }

    resetServiceForm();
    setTimeout(() => setNotification(null), 3500);
  };

  const handleEditService = (item: JenisPelayanan) => {
    setEditingServiceId(item.id);
    setServiceSeksi(item.seksi);
    setServiceKode(item.kode);
    setServiceNama(item.namaPelayanan);
    setServicePersyaratan(item.persyaratan ? item.persyaratan.join('\n') : '');
  };

  const handleDeleteService = (id: string, name: string) => {
    if (window.confirm(`Hapus jenis pelayanan "${name}"?`)) {
      deleteJenisPelayanan(id);
      setNotification({ type: 'success', message: 'Jenis pelayanan berhasil dihapus.' });
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const resetServiceForm = () => {
    setEditingServiceId(null);
    setServiceKode('');
    setServiceNama('');
    setServicePersyaratan('');
  };

  // --- Handlers: Desa ---
  const handleDesaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desaNama.trim() || !desaKode.trim()) {
      setNotification({ type: 'error', message: 'Nama dan Kode Desa wajib diisi.' });
      return;
    }

    if (editingDesaId) {
      updateDesa(editingDesaId, {
        namaDesa: desaNama.trim(),
        kodeDesa: desaKode.trim().toUpperCase(),
      });
      setNotification({ type: 'success', message: 'Data desa berhasil diperbarui!' });
    } else {
      addDesa({
        namaDesa: desaNama.trim(),
        kodeDesa: desaKode.trim().toUpperCase(),
      });
      setNotification({ type: 'success', message: 'Desa baru berhasil ditambahkan!' });
    }

    resetDesaForm();
    setTimeout(() => setNotification(null), 3500);
  };

  const handleEditDesa = (d: Desa) => {
    setEditingDesaId(d.id);
    setDesaNama(d.namaDesa);
    setDesaKode(d.kodeDesa);
  };

  const handleDeleteDesa = (id: string, name: string) => {
    if (window.confirm(`Hapus desa "${name}"?`)) {
      deleteDesa(id);
      setNotification({ type: 'success', message: 'Data desa berhasil dihapus.' });
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const resetDesaForm = () => {
    setEditingDesaId(null);
    setDesaNama('');
    setDesaKode('');
  };

  // Filtered Services List
  const filteredServices = jenisPelayananList.filter(j => {
    if (filterSeksi !== 'ALL' && j.seksi !== filterSeksi) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider">
            <span>Konfigurasi Referensi</span>
            <span>•</span>
            <span>Administrator PATEN</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mt-1">
            Pengelolaan Master Data
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Konfigurasi jenis permohonan layanan publik dan daftar desa se-Kecamatan Sukatani
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex flex-wrap bg-slate-100 p-1 rounded-lg border border-slate-200 self-start md:self-auto gap-1">
          <button
            onClick={() => setActiveSubTab('pelayanan')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
              activeSubTab === 'pelayanan'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Master Layanan ({jenisPelayananList.length})</span>
          </button>
          <button
            onClick={() => setActiveSubTab('desa')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
              activeSubTab === 'desa'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Master Desa ({desaList.length})</span>
          </button>
          <button
            onClick={() => setActiveSubTab('cloud')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
              activeSubTab === 'cloud'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Cloud className="w-3.5 h-3.5 text-blue-600" />
            <span>Basis Data Cloud & Migrasi</span>
          </button>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div
          className={`p-4 rounded-xl flex items-center gap-3 text-sm font-medium ${
            notification.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* SUBTAB 1: MASTER JENIS PELAYANAN */}
      {activeSubTab === 'pelayanan' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form Create / Edit */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:col-span-1 h-fit">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>{editingServiceId ? 'Edit Jenis Layanan' : 'Tambah Jenis Layanan'}</span>
              </h2>
              {editingServiceId && (
                <button
                  onClick={resetServiceForm}
                  className="text-xs text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                  title="Batal Edit"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <form onSubmit={handleServiceSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Seksi Penanggung Jawab <span className="text-red-500">*</span>
                </label>
                <select
                  value={serviceSeksi}
                  onChange={(e) => setServiceSeksi(e.target.value as SeksiType)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Yanlik">Seksi Pelayanan Publik (Yanlik)</option>
                  <option value="Pemerintahan">Seksi Pemerintahan & Pertanahan</option>
                  <option value="Ekbang">Seksi Ekonomi & Pembangunan (Ekbang)</option>
                  <option value="PMD">Seksi Pemberdayaan Masyarakat (PMD)</option>
                  <option value="Trantib">Seksi Ketenteraman & Ketertiban (Trantib)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kode Klasifikasi Surat <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400 text-xs font-mono">#</span>
                  <input
                    type="text"
                    required
                    placeholder="misal: 474, 503, 593"
                    value={serviceKode}
                    onChange={(e) => setServiceKode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Digunakan pada format penomoran registrasi otomatis
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Jenis Pelayanan <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="misal: Rekomendasi Surat Izin Mendirikan Bangunan (PBG)"
                  value={serviceNama}
                  onChange={(e) => setServiceNama(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Daftar Persyaratan (1 per baris)
                </label>
                <textarea
                  rows={4}
                  placeholder="KTP Pemohon&#10;Kartu Keluarga&#10;Surat Pengantar RT/RW/Desa"
                  value={servicePersyaratan}
                  onChange={(e) => setServicePersyaratan(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{editingServiceId ? 'Simpan Perubahan' : 'Tambah Layanan'}</span>
                </button>
                {editingServiceId && (
                  <button
                    type="button"
                    onClick={resetServiceForm}
                    className="py-2 px-3 border border-slate-300 text-slate-600 hover:bg-slate-50 text-xs font-medium rounded-lg cursor-pointer"
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Table of Services */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden lg:col-span-2">
            <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
              <div>
                <h3 className="text-sm font-bold text-slate-800">
                  Daftar Referensi Jenis Pelayanan
                </h3>
                <p className="text-xs text-slate-500">
                  Total {filteredServices.length} jenis layanan aktif
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Filter Seksi:</span>
                <select
                  value={filterSeksi}
                  onChange={(e) => setFilterSeksi(e.target.value)}
                  className="text-xs border border-slate-300 rounded-lg px-2.5 py-1 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="ALL">Semua Seksi</option>
                  <option value="Yanlik">Yanlik</option>
                  <option value="Pemerintahan">Pemerintahan</option>
                  <option value="Ekbang">Ekbang</option>
                  <option value="PMD">PMD</option>
                  <option value="Trantib">Trantib</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider">
                  <tr>
                    <th className="px-3 py-2.5 w-16">Kode</th>
                    <th className="px-3 py-2.5">Nama Pelayanan</th>
                    <th className="px-3 py-2.5 w-24">Seksi</th>
                    <th className="px-3 py-2.5 w-40">Persyaratan</th>
                    <th className="px-3 py-2.5 text-center w-20">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredServices.map((srv) => (
                    <tr key={srv.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-2.5 font-mono font-bold text-emerald-800">
                        {srv.kode}
                      </td>
                      <td className="px-3 py-2.5 font-medium text-slate-900">
                        {srv.namaPelayanan}
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          {srv.seksi}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-slate-500 text-[11px]">
                        {srv.persyaratan && srv.persyaratan.length > 0 ? (
                          <span title={srv.persyaratan.join(', ')}>
                            {srv.persyaratan.length} syarat
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => handleEditService(srv)}
                            className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                            title="Edit"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteService(srv.id, srv.namaPelayanan)}
                            className="p-1 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                            title="Hapus"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: MASTER DESA */}
      {activeSubTab === 'desa' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form Desa */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:col-span-1 h-fit">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>{editingDesaId ? 'Edit Data Desa' : 'Tambah Desa Baru'}</span>
              </h2>
              {editingDesaId && (
                <button
                  onClick={resetDesaForm}
                  className="text-xs text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                  title="Batal Edit"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <form onSubmit={handleDesaSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Desa <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="misal: Sukatani, Sukamulya"
                  value={desaNama}
                  onChange={(e) => setDesaNama(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kode Wilayah Desa <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400 text-xs font-mono">#</span>
                  <input
                    type="text"
                    required
                    placeholder="misal: 32.16.14.2001"
                    value={desaKode}
                    onChange={(e) => setDesaKode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-7 pr-3 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{editingDesaId ? 'Simpan Perubahan' : 'Tambah Desa'}</span>
                </button>
                {editingDesaId && (
                  <button
                    type="button"
                    onClick={resetDesaForm}
                    className="py-2 px-3 border border-slate-300 text-slate-600 hover:bg-slate-50 text-xs font-medium rounded-lg cursor-pointer"
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Table Desa */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden lg:col-span-2">
            <div className="p-4 border-b border-slate-200 bg-slate-50/50">
              <h3 className="text-sm font-bold text-slate-800">
                Daftar Wilayah Desa di Kecamatan Sukatani
              </h3>
              <p className="text-xs text-slate-500">
                Tercatat {desaList.length} desa resmi dalam cakupan wilayah hukum Kecamatan Sukatani
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider">
                  <tr>
                    <th className="px-3 py-2.5 text-center w-12">No</th>
                    <th className="px-3 py-2.5">Nama Desa</th>
                    <th className="px-3 py-2.5 font-mono">Kode Wilayah Kemendagri</th>
                    <th className="px-3 py-2.5 text-center w-24">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {desaList.map((d, index) => (
                    <tr key={d.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-2.5 text-center text-slate-400 font-medium">
                        {index + 1}
                      </td>
                      <td className="px-3 py-2.5 font-bold text-slate-900">
                        Desa {d.namaDesa}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-emerald-800 font-medium">
                        {d.kodeDesa}
                      </td>
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => handleEditDesa(d)}
                            className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                            title="Edit Desa"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteDesa(d.id, d.namaDesa)}
                            className="p-1 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                            title="Hapus Desa"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: Basis Data Cloud & Migrasi Data */}
      {activeSubTab === 'cloud' && (
        <div className="space-y-6">
          {/* Status & Overview Card */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shrink-0">
                  <Cloud className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-lg font-bold text-slate-800">
                      Basis Data Daring Cloud (Google Cloud Firestore)
                    </h2>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      Aktif & Tersinkronisasi
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 max-w-2xl">
                    Data pengguna, master data, dan seluruh catatan registrasi pelayanan PATEN disimpan di server basis data daring terpusat agar sinkron otomatis di seluruh komputer petugas loket dan perangkat pimpinan.
                  </p>
                </div>
              </div>

              {/* Action Button: Trigger Manual Migration */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  id="btn-trigger-cloud-migration"
                  type="button"
                  disabled={isMigrating}
                  onClick={async () => {
                    setMigrationStatusMsg(null);
                    const res = await forceCloudSync();
                    setMigrationStatusMsg(res.message);
                    setTimeout(() => setMigrationStatusMsg(null), 7000);
                  }}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold text-white shadow-xs cursor-pointer transition-all ${
                    isMigrating 
                      ? 'bg-blue-400 cursor-not-allowed' 
                      : 'bg-blue-600 hover:bg-blue-700 active:scale-98'
                  }`}
                >
                  <RefreshCw className={`w-4 h-4 ${isMigrating ? 'animate-spin' : ''}`} />
                  <span>{isMigrating ? 'Memigrasikan Data...' : 'Migrasi & Sinkronkan Sekarang'}</span>
                </button>
              </div>
            </div>

            {/* Notification Banner when Migration Ran */}
            {migrationStatusMsg && (
              <div className="mt-4 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3 text-xs font-medium">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{migrationStatusMsg}</span>
              </div>
            )}

            {/* Database Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-500">Akun Petugas</span>
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-bold text-slate-800 mt-2">
                  {users.length}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Koleksi: <code className="font-mono text-emerald-700">users</code>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-500">Berkas Register</span>
                  <FileText className="w-4 h-4 text-blue-600" />
                </div>
                <div className="text-2xl font-bold text-slate-800 mt-2">
                  {records.length}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Koleksi: <code className="font-mono text-blue-700">records</code>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-500">Master Desa</span>
                  <MapPin className="w-4 h-4 text-amber-600" />
                </div>
                <div className="text-2xl font-bold text-slate-800 mt-2">
                  {desaList.length}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Koleksi: <code className="font-mono text-amber-700">desa</code>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-500">Jenis Layanan</span>
                  <Layers className="w-4 h-4 text-purple-600" />
                </div>
                <div className="text-2xl font-bold text-slate-800 mt-2">
                  {jenisPelayananList.length}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Koleksi: <code className="font-mono text-purple-700">jenis_pelayanan</code>
                </div>
              </div>
            </div>
          </div>

          {/* Database Info & Architecture Specification */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Info Card */}
            <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <Server className="w-4 h-4 text-slate-700" />
                <h3 className="text-sm font-bold text-slate-800">
                  Spesifikasi Basis Data Terpusat
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex items-start justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">ID Database Firestore:</span>
                  <span className="font-mono font-bold text-slate-800 text-right break-all ml-2">
                    ai-studio-patenkecsukatani-3ffd2b77-6435-4351-99e9-36fe8f25f52d
                  </span>
                </div>
                <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Tipe Penyimpanan:</span>
                  <span className="font-medium text-slate-800">Cloud Firestore (Real-time NoSQL)</span>
                </div>
                <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Status Konektivitas:</span>
                  <span className={`inline-flex items-center gap-1 font-semibold ${isOnline ? 'text-emerald-700' : 'text-amber-700'}`}>
                    <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                    {isOnline ? 'Online (Terhubung ke Cloud)' : 'Offline (Tersimpan di Cache)'}
                  </span>
                </div>
                <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Sinkronisasi Terakhir:</span>
                  <span className="font-mono font-medium text-slate-800">
                    {lastSyncTime ? `${lastSyncTime} WIB` : 'Sinkron otomatis real-time'}
                  </span>
                </div>
                <div className="flex items-center justify-between py-1.5">
                  <span className="text-slate-500">Dukungan Multi-Tab & Offline:</span>
                  <span className="font-semibold text-emerald-700">Aktif (Persistent Cache Manager)</span>
                </div>
              </div>
            </div>

            {/* Sync Mechanics Card */}
            <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <Laptop className="w-4 h-4 text-slate-700" />
                <h3 className="text-sm font-bold text-slate-800">
                  Keunggulan Migrasi Cloud Antarperangkat
                </h3>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-600">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>Penyimpanan Terpusat:</strong> Data tidak lagi terkunci di satu browser (localStorage) saja, melainkan aman tersimpan di cloud database Google.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>Sinkronisasi Real-Time (onSnapshot):</strong> Setiap pendaftaran berkas baru oleh petugas loket akan otomatis muncul di layar pimpinan/seksi lain tanpa perlu refresh.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>Toleransi Gangguan Jaringan (Offline Cache):</strong> Jika internet terputus, petugas tetap dapat menginput berkas ke offline cache, dan otomatis diunggah saat koneksi pulih.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>Migrasi Sekali Klik:</strong> Tombol di atas memastikan seluruh data yang sebelumnya ada di peramban langsung ter-copy ke Firestore dengan integritas data terjaga.
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
