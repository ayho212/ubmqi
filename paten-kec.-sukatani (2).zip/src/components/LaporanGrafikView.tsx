import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SeksiType } from '../types';
import { downloadLaporanRekapitulasiPDF } from '../utils/exportPdf';
import { 
  BarChart3, 
  Download, 
  Calendar, 
  Filter, 
  FileSpreadsheet, 
  Printer, 
  Search, 
  ArrowDownToLine, 
  Building, 
  PieChart as PieChartIcon, 
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

export const LaporanGrafikView: React.FC = () => {
  const { records, jenisPelayananList, desaList, currentUser, isAdmin, getUserSeksi } = useApp();
  const userSeksi = getUserSeksi();

  // Filters
  const [filterSeksi, setFilterSeksi] = useState<string>(isAdmin ? 'ALL' : (userSeksi || 'Yanlik'));
  const [filterDesaId, setFilterDesaId] = useState<string>('ALL');
  const [filterJenisId, setFilterJenisId] = useState<string>('ALL');
  const [startDate, setStartDate] = useState<string>(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  });
  const [endDate, setEndDate] = useState<string>(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  });
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Filter records
  const filteredRecords = records.filter((r) => {
    // Seksi filter
    if (filterSeksi !== 'ALL' && r.seksi !== filterSeksi) return false;
    if (!isAdmin && userSeksi && r.seksi !== userSeksi) return false;

    // Desa filter
    if (filterDesaId !== 'ALL' && r.desaId !== filterDesaId) return false;

    // Jenis pelayanan filter
    if (filterJenisId !== 'ALL' && r.jenisPelayananId !== filterJenisId) return false;

    // Date range
    if (startDate && r.tanggal < startDate) return false;
    if (endDate && r.tanggal > endDate) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        r.nomorRegistrasi.toLowerCase().includes(q) ||
        r.namaPemohon.toLowerCase().includes(q) ||
        (r.nik && r.nik.includes(q)) ||
        (r.perihal && r.perihal.toLowerCase().includes(q)) ||
        r.namaPelayanan.toLowerCase().includes(q) ||
        r.namaDesa.toLowerCase().includes(q)
      );
    }

    return true;
  });

  // Export to PDF
  const handleExportPDF = () => {
    const filterTitle = filterSeksi === 'ALL' ? 'Semua Seksi' : `Seksi ${filterSeksi}`;
    downloadLaporanRekapitulasiPDF({
      filterTitle,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
      records: filteredRecords,
    });
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'No',
      'Tanggal',
      'No Registrasi',
      'Perihal',
      'Nama Pemohon',
      'NIK',
      'Desa',
      'Alamat',
      'Seksi',
      'Jenis Pelayanan',
      'Keterangan',
      'Petugas'
    ];

    const rows = filteredRecords.map((r, idx) => [
      idx + 1,
      r.tanggal,
      `"${r.nomorRegistrasi}"`,
      `"${r.perihal || r.namaPelayanan}"`,
      `"${r.namaPemohon}"`,
      `'${r.nik || ''}`,
      `"${r.namaDesa}"`,
      `"${r.alamat || ''}"`,
      `"${r.seksi}"`,
      `"${r.namaPelayanan}"`,
      `"${r.keterangan || ''}"`,
      `"${r.petugas}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + 
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Rekapitulasi_PATEN_Sukatani_${startDate}_sd_${endDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleResetFilter = () => {
    setFilterSeksi(isAdmin ? 'ALL' : (userSeksi || 'Yanlik'));
    setFilterDesaId('ALL');
    setFilterJenisId('ALL');
    setSearchQuery('');
  };

  // Available services based on filterSeksi
  const availableServices = filterSeksi === 'ALL'
    ? jenisPelayananList
    : jenisPelayananList.filter((j) => j.seksi === filterSeksi);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider">
            <span>Pelaporan & Rekapitulasi</span>
            <span>•</span>
            <span>Kecamatan Sukatani</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mt-1">
            Laporan & Grafik Pelayanan
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Analisis data pelayanan terpadu, rekapitulasi berkas, serta ekspor resmi laporan dinas
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="btn-export-rekap-excel"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            <span>Ekspor Excel (.CSV)</span>
          </button>
          <button
            id="btn-export-rekap-pdf"
            onClick={handleExportPDF}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors shadow-sm cursor-pointer"
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>Unduh Laporan Resmi (PDF)</span>
          </button>
        </div>
      </div>

      {/* FILTER CONTROL CARD */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
            <Filter className="w-4 h-4 text-emerald-600" />
            <span>Parameter Filter Laporan</span>
          </div>
          <button
            onClick={handleResetFilter}
            className="text-xs text-slate-500 hover:text-emerald-700 flex items-center gap-1 cursor-pointer font-medium"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filter</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Seksi Filter */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Seksi Bidang</label>
            <select
              value={filterSeksi}
              onChange={(e) => {
                setFilterSeksi(e.target.value);
                setFilterJenisId('ALL');
              }}
              disabled={!isAdmin}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:opacity-60"
            >
              {isAdmin && <option value="ALL">Semua Seksi Bidang</option>}
              <option value="Yanlik">Seksi Yanlik</option>
              <option value="Pemerintahan">Seksi Pemerintahan</option>
              <option value="Ekbang">Seksi Ekbang</option>
              <option value="PMD">Seksi PMD</option>
              <option value="Trantib">Seksi Trantib</option>
            </select>
          </div>

          {/* Desa Filter */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Desa Asal</label>
            <select
              value={filterDesaId}
              onChange={(e) => setFilterDesaId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">Semua Desa (7 Desa)</option>
              {desaList.map((d) => (
                <option key={d.id} value={d.id}>
                  Desa {d.namaDesa}
                </option>
              ))}
            </select>
          </div>

          {/* Jenis Pelayanan Filter */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Jenis Layanan</label>
            <select
              value={filterJenisId}
              onChange={(e) => setFilterJenisId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 truncate"
            >
              <option value="ALL">Semua Jenis Layanan</option>
              {availableServices.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.namaPelayanan}
                </option>
              ))}
            </select>
          </div>

          {/* Tanggal Mulai */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Tanggal Mulai</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Tanggal Sampai */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Tanggal Sampai</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* STATISTIK RINGKAS HASIL FILTER */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Total Dokumen Hasil Filter</p>
            <p className="text-2xl font-extrabold text-slate-800 mt-1">{filteredRecords.length} Berkas</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Cakupan Wilayah</p>
            <p className="text-2xl font-extrabold text-slate-800 mt-1">
              {filterDesaId === 'ALL' ? '7 Desa' : '1 Desa Terpilih'}
            </p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Building className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Rentang Waktu</p>
            <p className="text-xs font-bold text-slate-800 mt-2 font-mono">
              {startDate} s/d {endDate}
            </p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
            <Calendar className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* TABLE REKAPITULASI RESMI */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-800">
              Tabel Rekapitulasi Pelayanan Terpadu
            </h2>
            <p className="text-xs text-slate-500">
              Menampilkan {filteredRecords.length} data registrasi sesuai kriteria pencarian
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari dalam hasil..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider">
              <tr>
                <th className="px-3 py-3 text-center w-10">No</th>
                <th className="px-3 py-3 w-24">Tanggal</th>
                <th className="px-3 py-3 w-40 font-mono">No. Reg</th>
                <th className="px-3 py-3">Perihal</th>
                <th className="px-3 py-3">Pemohon</th>
                <th className="px-3 py-3 font-mono">NIK</th>
                <th className="px-3 py-3">Desa</th>
                <th className="px-3 py-3">Seksi</th>
                <th className="px-3 py-3">Petugas</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                    Tidak ada berkas yang sesuai dengan parameter filter yang dipilih.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r, idx) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-3 py-2.5 text-center text-slate-400 font-medium">{idx + 1}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap text-slate-600">{r.tanggal}</td>
                    <td className="px-3 py-2.5 font-mono font-medium text-emerald-800 whitespace-nowrap">
                      {r.nomorRegistrasi}
                    </td>
                    <td className="px-3 py-2.5 font-medium text-slate-800">{r.perihal || r.namaPelayanan}</td>
                    <td className="px-3 py-2.5 font-semibold text-slate-900 whitespace-nowrap">{r.namaPemohon}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-600 whitespace-nowrap">{r.nik || '-'}</td>
                    <td className="px-3 py-2.5 text-slate-700 whitespace-nowrap">{r.namaDesa}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700">
                        {r.seksi}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-slate-600 whitespace-nowrap">{r.petugas}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
