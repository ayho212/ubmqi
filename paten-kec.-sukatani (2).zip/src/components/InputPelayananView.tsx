import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PelayananRecord, SeksiType } from '../types';
import { downloadBukuRegisterPDF } from '../utils/exportPdf';
import { BuktiSerahTerimaModal } from './BuktiSerahTerimaModal';
import { 
  FileEdit, 
  Save, 
  Trash2, 
  Edit3, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  Hash, 
  Calendar, 
  MapPin, 
  User, 
  FileText,
  RotateCcw,
  BookOpen,
  Printer,
  Download,
  CreditCard,
  Home,
  CloudCheck,
  AlertTriangle,
  X,
  Link2,
  ExternalLink
} from 'lucide-react';

export const InputPelayananView: React.FC = () => {
  const { 
    currentUser, 
    isAdmin, 
    getUserSeksi, 
    jenisPelayananList, 
    desaList, 
    records, 
    generateNomorRegistrasi,
    addPelayananRecord,
    updatePelayananRecord,
    deletePelayananRecord 
  } = useApp();

  const userSeksi = getUserSeksi();

  // Active Buku Register tab (For Admin, can switch between seksi registers; for seksi staff, locked to their seksi)
  const [activeRegisterSeksi, setActiveRegisterSeksi] = useState<SeksiType>(userSeksi || 'Yanlik');

  useEffect(() => {
    if (userSeksi) {
      setActiveRegisterSeksi(userSeksi);
    }
  }, [userSeksi]);

  // Filter available services based on active register seksi
  const filteredServices = jenisPelayananList.filter((j) => j.seksi === activeRegisterSeksi);

  // Form states matching PDF specification:
  // (Tanggal, Perihal, No Reg, Nama Pemohon, NIK, Desa, Kp/RT/RW, Keterangan, Link Google Drive)
  const [selectedServiceId, setSelectedServiceId] = useState<string>('');
  const [tanggal, setTanggal] = useState<string>(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  });
  const [perihal, setPerihal] = useState<string>('');
  const [nomorRegistrasi, setNomorRegistrasi] = useState<string>('');
  const [namaPemohon, setNamaPemohon] = useState<string>('');
  const [nik, setNik] = useState<string>('');
  const [desaId, setDesaId] = useState<string>('');
  const [alamat, setAlamat] = useState<string>('');
  const [keterangan, setKeterangan] = useState<string>('');
  const [linkGoogleDrive, setLinkGoogleDrive] = useState<string>('');

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Print Preview Modal
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Bukti Serah Terima Modal
  const [buktiRecord, setBuktiRecord] = useState<PelayananRecord | null>(null);

  // Delete states (Single & Bulk Delete Modal)
  const [recordToDelete, setRecordToDelete] = useState<PelayananRecord | null>(null);
  const [selectedRecordIds, setSelectedRecordIds] = useState<string[]>([]);
  const [isBulkDeleteOpen, setIsBulkDeleteOpen] = useState(false);

  // Default initial selection
  useEffect(() => {
    if (filteredServices.length > 0 && (!selectedServiceId || !filteredServices.some(s => s.id === selectedServiceId))) {
      setSelectedServiceId(filteredServices[0].id);
    }
  }, [filteredServices, selectedServiceId]);

  useEffect(() => {
    if (desaList.length > 0 && !desaId) {
      setDesaId(desaList[0].id);
    }
  }, [desaList, desaId]);

  // Regenerate registration number when service or date changes (unless editing)
  useEffect(() => {
    if (!editingId && selectedServiceId && tanggal) {
      const generated = generateNomorRegistrasi(selectedServiceId, tanggal);
      setNomorRegistrasi(generated);
    }
  }, [selectedServiceId, tanggal, editingId, generateNomorRegistrasi]);

  const selectedService = jenisPelayananList.find(j => j.id === selectedServiceId);
  const selectedDesa = desaList.find(d => d.id === desaId);

  // Set default perihal when service changes
  const handleServiceChange = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    const srv = jenisPelayananList.find(j => j.id === serviceId);
    if (srv && !editingId && !perihal) {
      setPerihal(srv.namaPelayanan);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedServiceId) {
      setNotification({ type: 'error', message: 'Silakan pilih jenis pelayanan.' });
      return;
    }
    if (!namaPemohon.trim()) {
      setNotification({ type: 'error', message: 'Nama pemohon wajib diisi.' });
      return;
    }
    if (!nik.trim() || nik.trim().length < 16) {
      setNotification({ type: 'error', message: 'NIK wajib 16 digit angka.' });
      return;
    }
    if (!desaId) {
      setNotification({ type: 'error', message: 'Silakan pilih desa asal.' });
      return;
    }

    if (editingId) {
      // Update existing record
      updatePelayananRecord(editingId, {
        jenisPelayananId: selectedServiceId,
        namaPelayanan: selectedService?.namaPelayanan || '',
        seksi: selectedService?.seksi || activeRegisterSeksi,
        nomorRegistrasi,
        tanggal,
        perihal: perihal.trim() || (selectedService?.namaPelayanan || ''),
        namaPemohon: namaPemohon.trim(),
        nik: nik.trim(),
        desaId,
        namaDesa: selectedDesa?.namaDesa || '',
        alamat: alamat.trim(),
        keterangan: keterangan.trim(),
        linkGoogleDrive: linkGoogleDrive.trim(),
      });
      setNotification({ type: 'success', message: 'Data Buku Register berhasil diperbarui di Cloud Database Firestore!' });
      resetForm();
    } else {
      // Add new record
      const finalNoReg = nomorRegistrasi || generateNomorRegistrasi(selectedServiceId, tanggal);
      addPelayananRecord({
        nomorRegistrasi: finalNoReg,
        jenisPelayananId: selectedServiceId,
        namaPelayanan: selectedService?.namaPelayanan || '',
        tanggal,
        perihal: perihal.trim() || (selectedService?.namaPelayanan || ''),
        namaPemohon: namaPemohon.trim(),
        nik: nik.trim(),
        desaId,
        namaDesa: selectedDesa?.namaDesa || '',
        alamat: alamat.trim(),
        keterangan: keterangan.trim(),
        petugas: currentUser.name,
        seksi: selectedService?.seksi || activeRegisterSeksi,
        linkGoogleDrive: linkGoogleDrive.trim(),
      });
      setNotification({ 
        type: 'success', 
        message: `Pelayanan berhasil dicatat di Cloud Firestore & Buku Register dengan No. Reg ${finalNoReg}!` 
      });

      // Clear input fields
      setNamaPemohon('');
      setNik('');
      setAlamat('');
      setKeterangan('');
      setPerihal('');
      setLinkGoogleDrive('');
    }

    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const handleEditClick = (rec: PelayananRecord) => {
    setEditingId(rec.id);
    setActiveRegisterSeksi(rec.seksi);
    setSelectedServiceId(rec.jenisPelayananId);
    setNomorRegistrasi(rec.nomorRegistrasi);
    setTanggal(rec.tanggal);
    setPerihal(rec.perihal || rec.namaPelayanan);
    setNamaPemohon(rec.namaPemohon);
    setNik(rec.nik || '');
    setDesaId(rec.desaId);
    setAlamat(rec.alamat || '');
    setKeterangan(rec.keterangan || '');
    setLinkGoogleDrive(rec.linkGoogleDrive || '');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteClick = (rec: PelayananRecord) => {
    setRecordToDelete(rec);
  };

  const handleConfirmDeleteSingle = () => {
    if (!recordToDelete) return;
    const deletedNoReg = recordToDelete.nomorRegistrasi;
    const deletedId = recordToDelete.id;
    deletePelayananRecord(deletedId);
    if (editingId === deletedId) {
      resetForm();
    }
    setSelectedRecordIds(prev => prev.filter(id => id !== deletedId));
    setRecordToDelete(null);
    setNotification({ 
      type: 'success', 
      message: `Data register ${deletedNoReg} berhasil dihapus!` 
    });
    setTimeout(() => setNotification(null), 4000);
  };

  const handleToggleSelectAll = () => {
    if (displayedRecords.length === 0) return;
    if (selectedRecordIds.length === displayedRecords.length) {
      setSelectedRecordIds([]);
    } else {
      setSelectedRecordIds(displayedRecords.map(r => r.id));
    }
  };

  const handleToggleSelectRecord = (id: string) => {
    setSelectedRecordIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleConfirmBulkDelete = () => {
    if (selectedRecordIds.length === 0) return;
    const count = selectedRecordIds.length;
    selectedRecordIds.forEach(id => {
      deletePelayananRecord(id);
      if (editingId === id) resetForm();
    });
    setSelectedRecordIds([]);
    setIsBulkDeleteOpen(false);
    setNotification({ 
      type: 'success', 
      message: `${count} data register berhasil dihapus dari Buku Register!` 
    });
    setTimeout(() => setNotification(null), 4000);
  };

  const resetForm = () => {
    setEditingId(null);
    setNamaPemohon('');
    setNik('');
    setAlamat('');
    setKeterangan('');
    setPerihal('');
    setLinkGoogleDrive('');
    if (filteredServices.length > 0) {
      setSelectedServiceId(filteredServices[0].id);
    }
  };

  // Get Register Title per Seksi
  const getRegisterTitle = (seksi: SeksiType): string => {
    switch (seksi) {
      case 'Yanlik':
        return 'Buku Register Pelayanan Publik (Yanlik)';
      case 'Pemerintahan':
        return 'Buku Register Pertanahan & Ahli Waris (Seksi Pemerintahan)';
      case 'Ekbang':
        return 'Buku Register Rekomendasi Pembangunan (Seksi Ekbang)';
      case 'PMD':
        return 'Buku Register Pelayanan PMD (Pemberdayaan Masyarakat & Desa)';
      case 'Trantib':
        return 'Buku Register Ketenteraman & Ketertiban (Seksi Trantib)';
    }
  };

  // Filter records by current register and search
  const registerRecords = records.filter(r => {
    if (isAdmin) {
      return r.seksi === activeRegisterSeksi;
    }
    return r.seksi === userSeksi;
  });

  const displayedRecords = registerRecords.filter(r => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.nomorRegistrasi.toLowerCase().includes(q) ||
      r.namaPemohon.toLowerCase().includes(q) ||
      (r.nik && r.nik.includes(q)) ||
      (r.perihal && r.perihal.toLowerCase().includes(q)) ||
      r.namaPelayanan.toLowerCase().includes(q) ||
      r.namaDesa.toLowerCase().includes(q) ||
      (r.alamat && r.alamat.toLowerCase().includes(q)) ||
      (r.linkGoogleDrive && r.linkGoogleDrive.toLowerCase().includes(q))
    );
  });

  // Export to CSV / Excel
  const handleExportCSV = () => {
    const headers = [
      'No',
      'Tanggal',
      'Nomor Registrasi',
      'Perihal',
      'Nama Pemohon',
      'NIK',
      'Desa',
      'Alamat (Kp/RT/RW)',
      'Seksi',
      'Keterangan',
      'Upload Dokumen (Link Google Drive)',
      'Petugas'
    ];

    const rows = displayedRecords.map((r, index) => [
      index + 1,
      r.tanggal,
      `"${r.nomorRegistrasi}"`,
      `"${r.perihal || r.namaPelayanan}"`,
      `"${r.namaPemohon}"`,
      `'${r.nik || ''}`,
      `"${r.namaDesa}"`,
      `"${r.alamat || ''}"`,
      `"${r.seksi}"`,
      `"${r.keterangan || ''}"`,
      `"${r.linkGoogleDrive || ''}"`,
      `"${r.petugas}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + 
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Buku_Register_${activeRegisterSeksi}_Sukatani_${tanggal}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Title & Scope header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Form Input & Buku Register
            </span>
            <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-medium">
              {isAdmin ? 'Mode Administrator (Semua Seksi)' : `Petugas Seksi ${userSeksi}`}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mt-1">
            {getRegisterTitle(activeRegisterSeksi)}
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Pencatatan registrasi dokumen pelayanan masyarakat (Tanggal, Perihal, No Reg, Nama Pemohon, NIK, Desa, Kp/RT/RW, Keterangan).
          </p>
        </div>

        {/* Seksi Switcher (Enabled for Admin, read-only tag for staff) */}
        {isAdmin ? (
          <div className="flex flex-col gap-1.5 w-full md:w-auto">
            <span className="text-xs font-semibold text-slate-500">Pilih Seksi Pelayanan:</span>
            <select
              id="select-register-seksi"
              value={activeRegisterSeksi}
              onChange={(e) => {
                setActiveRegisterSeksi(e.target.value as SeksiType);
                resetForm();
              }}
              className="text-xs font-medium border border-slate-300 rounded-lg px-3 py-2 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
            >
              <option value="Yanlik">▶ Seksi Pelayanan Publik (Yanlik)</option>
              <option value="Pemerintahan">▶ Seksi Pemerintahan</option>
              <option value="Ekbang">▶ Seksi Ekonomi & Pembangunan (Ekbang)</option>
              <option value="PMD">▶ Seksi Pemberdayaan Masyarakat & Desa (PMD)</option>
              <option value="Trantib">▶ Seksi Ketenteraman & Ketertiban (Trantib)</option>
            </select>
          </div>
        ) : (
          <div className="px-3.5 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-medium text-emerald-800">
            Hak Akses: <strong>Seksi {activeRegisterSeksi}</strong> ({currentUser.level})
          </div>
        )}
      </div>

      {/* Administrator Seksi Bar: Input Data Pelayanan (Semua Seksi) */}
      {isAdmin && (
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
              <span>Level 1: Administrator — Input Data Pelayanan (Semua Seksi)</span>
            </div>
            <span className="text-[11px] text-slate-500">
              Pilih tab seksi di bawah untuk menginput data pelayanan masing-masing bidang:
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
            {[
              { key: 'Yanlik' as SeksiType, label: 'Seksi Pelayanan Publik (Yanlik)', level: 'Level 2' },
              { key: 'Pemerintahan' as SeksiType, label: 'Seksi Pemerintahan', level: 'Level 3' },
              { key: 'Ekbang' as SeksiType, label: 'Seksi Ekonomi & Pembangunan (Ekbang)', level: 'Level 4' },
              { key: 'PMD' as SeksiType, label: 'Seksi Pemberdayaan Masyarakat & Desa (PMD)', level: 'Level 5' },
              { key: 'Trantib' as SeksiType, label: 'Seksi Ketenteraman & Ketertiban (Trantib)', level: 'Level 6' },
            ].map((item) => {
              const isSelected = activeRegisterSeksi === item.key;
              const count = records.filter(r => r.seksi === item.key).length;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => {
                    setActiveRegisterSeksi(item.key);
                    resetForm();
                  }}
                  className={`px-3 py-2.5 rounded-lg text-left text-xs transition-all border cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm font-semibold'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">
                      {item.level}
                    </span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${isSelected ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-200 text-slate-600 font-medium'}`}>
                      {count} data
                    </span>
                  </div>
                  <div className="leading-tight truncate font-medium">
                    {item.label}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Alert Notification */}
      {notification && (
        <div
          className={`p-4 rounded-xl flex items-center gap-3 text-sm font-medium ${
            notification.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Form Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <FileEdit className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">
                {editingId ? 'Edit Data Buku Register' : `Formulir Registrasi — Seksi ${activeRegisterSeksi}`}
              </h2>
              <p className="text-xs text-slate-500">
                Lengkapi seluruh formulir buku register sesuai berkas permohonan warga
              </p>
            </div>
          </div>
          {editingId && (
            <button
              onClick={resetForm}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Batal Edit</span>
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Row 1: Jenis Pelayanan */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Jenis Pelayanan <span className="text-red-500">*</span>
            </label>
            <select
              id="select-jenis-pelayanan"
              value={selectedServiceId}
              onChange={(e) => handleServiceChange(e.target.value)}
              required
              className="w-full bg-white border border-slate-300 rounded-lg px-3.5 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {filteredServices.length === 0 ? (
                <option value="">Tidak ada jenis pelayanan pada seksi ini</option>
              ) : activeRegisterSeksi === 'Yanlik' ? (
                <>
                  {/* Seksi Pelayanan Publik (Yanlik) items */}
                  {filteredServices.filter(j => !j.id.startsWith('jp-ynl-03')).map((j) => (
                    <option key={j.id} value={j.id}>
                      {j.namaPelayanan}
                    </option>
                  ))}
                  <optgroup label="Surat Keterangan Tidak Mampu (SKTM)">
                    {filteredServices.filter(j => j.id.startsWith('jp-ynl-03')).map((j) => (
                      <option key={j.id} value={j.id}>
                        &nbsp;&nbsp;• {j.namaPelayanan.replace('Surat Keterangan Tidak Mampu (SKTM) - ', '')}
                      </option>
                    ))}
                  </optgroup>
                </>
              ) : (
                filteredServices.map((j) => (
                  <option key={j.id} value={j.id}>
                    {j.namaPelayanan}
                  </option>
                ))
              )}
            </select>
          </div>

          {/* Row 2: Nomor Registrasi & Tanggal */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>No. Registrasi (Otomatis)</span>
                <span className="text-emerald-700 text-[11px] font-medium lowercase">
                  # format resmi
                </span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-emerald-700">
                  <Hash className="w-4 h-4" />
                </div>
                <input
                  id="input-nomor-registrasi"
                  type="text"
                  value={nomorRegistrasi}
                  readOnly
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm font-mono font-bold text-emerald-800 cursor-default"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Tanggal Pelayanan <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-slate-400">
                  <Calendar className="w-4 h-4" />
                </div>
                <input
                  id="input-tanggal-pelayanan"
                  type="date"
                  value={tanggal}
                  onChange={(e) => setTanggal(e.target.value)}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Row 3: Perihal Permohonan */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Perihal <span className="text-red-500">*</span>
            </label>
            <div className="relative flex items-center">
              <div className="absolute left-3.5 text-slate-400">
                <FileText className="w-4 h-4" />
              </div>
              <input
                id="input-perihal"
                type="text"
                placeholder="misal: Permohonan SKTM Jamkesda Rawat Inap, AJB Tanah Blok C, Rekomendasi PBG"
                value={perihal}
                onChange={(e) => setPerihal(e.target.value)}
                required
                className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Row 4: Nama Pemohon & NIK */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Nama Pemohon <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="input-nama-pemohon"
                  type="text"
                  placeholder="Nama pemohon / badan hukum"
                  value={namaPemohon}
                  onChange={(e) => setNamaPemohon(e.target.value)}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                NIK (16 Digit) <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-slate-400">
                  <CreditCard className="w-4 h-4" />
                </div>
                <input
                  id="input-nik"
                  type="text"
                  maxLength={16}
                  placeholder="321614xxxxxxxxxx"
                  value={nik}
                  onChange={(e) => setNik(e.target.value.replace(/\D/g, ''))}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Row 5: Desa & Kp/RT/RW */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Desa Asal <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-slate-400">
                  <MapPin className="w-4 h-4" />
                </div>
                <select
                  id="select-desa-asal"
                  value={desaId}
                  onChange={(e) => setDesaId(e.target.value)}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {desaList.map((d) => (
                    <option key={d.id} value={d.id}>
                      Desa {d.namaDesa} ({d.kodeDesa})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Alamat (Kp/RT/RW)
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-slate-400">
                  <Home className="w-4 h-4" />
                </div>
                <input
                  id="input-alamat"
                  type="text"
                  placeholder="misal: Kp. Jagawana RT 002/RW 003"
                  value={alamat}
                  onChange={(e) => setAlamat(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Row 6: Keterangan */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Keterangan
            </label>
            <textarea
              id="input-keterangan"
              rows={2}
              placeholder="Catatan kelengkapan berkas, nomor pengantar surat desa, peruntukan khusus, dsb."
              value={keterangan}
              onChange={(e) => setKeterangan(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3.5 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Row 7: Upload dokumen (link google drive) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Upload dokumen (link google drive)</span>
              <span className="text-slate-400 text-[11px] font-normal lowercase">
                opsional — tautan berkas / folder drive
              </span>
            </label>
            <div className="relative flex items-center">
              <div className="absolute left-3.5 text-emerald-600">
                <Link2 className="w-4 h-4" />
              </div>
              <input
                id="input-link-google-drive"
                type="url"
                placeholder="https://drive.google.com/... (masukkan tautan berkas scan / folder Google Drive pemohon)"
                value={linkGoogleDrive}
                onChange={(e) => setLinkGoogleDrive(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg pl-10 pr-24 py-2 text-sm font-mono text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              {linkGoogleDrive && (
                <div className="absolute right-2 flex items-center">
                  <a
                    href={linkGoogleDrive.startsWith('http') ? linkGoogleDrive : `https://${linkGoogleDrive}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 rounded-md text-[11px] font-semibold transition-colors cursor-pointer"
                    title="Buka tautan Google Drive di tab baru"
                  >
                    <span>Buka Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Lampirkan link Google Drive dokumen persyaratan pemohon (seperti scan KTP, KK, Surat Pengantar Desa, dsb.)
            </p>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-3">
            <button
              id="btn-simpan-pelayanan"
              type="submit"
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-sm rounded-lg transition-colors shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{editingId ? 'Perbarui Data Register' : 'Simpan ke Buku Register'}</span>
            </button>

            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2.5 border border-slate-300 text-slate-700 text-sm rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
            )}
          </div>
        </form>
      </div>

      {/* TABLE SECTION: BUKU REGISTER RESMI */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-700" />
              <h2 className="text-base font-bold text-slate-800">
                {getRegisterTitle(activeRegisterSeksi)}
              </h2>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                <CloudCheck className="w-3 h-3 text-emerald-600" />
                <span>Real-time Cloud</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Menampilkan {displayedRecords.length} berkas registrasi resmi
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="search-input-pelayanan"
                type="text"
                placeholder="Cari nama, NIK, No. Reg..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Export Excel Button */}
            <button
              id="btn-export-excel"
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
              title="Export data register ke format Excel (CSV)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Excel</span>
            </button>

            {/* Cetak PDF Button */}
            <button
              id="btn-cetak-pdf"
              onClick={() => setIsPrintModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer"
              title="Pratinjau cetak Buku Register resmi"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak PDF</span>
            </button>
          </div>
        </div>

        {/* Bulk Action Bar when records are selected */}
        {selectedRecordIds.length > 0 && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 py-2.5 flex items-center justify-between text-xs transition-all">
            <div className="flex items-center gap-2 text-amber-900 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>
                <strong>{selectedRecordIds.length}</strong> data register terpilih
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                id="btn-cancel-selection"
                type="button"
                onClick={() => setSelectedRecordIds([])}
                className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-300 rounded-md hover:bg-slate-50 cursor-pointer"
              >
                Batal Pilih
              </button>
              <button
                id="btn-bulk-delete-records"
                type="button"
                onClick={() => setIsBulkDeleteOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-md shadow-xs transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Terpilih ({selectedRecordIds.length})</span>
              </button>
            </div>
          </div>
        )}

        {/* Responsive Table for Buku Register */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider">
              <tr>
                <th className="px-3 py-3 text-center w-10">
                  <input
                    type="checkbox"
                    id="checkbox-select-all-records"
                    checked={displayedRecords.length > 0 && selectedRecordIds.length === displayedRecords.length}
                    onChange={handleToggleSelectAll}
                    className="rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer w-3.5 h-3.5"
                    title="Pilih Semua Data"
                  />
                </th>
                <th className="px-3 py-3 text-center w-10">No</th>
                <th className="px-3 py-3 w-24">Tanggal</th>
                <th className="px-3 py-3 w-44">No. Reg</th>
                <th className="px-3 py-3">Perihal</th>
                <th className="px-3 py-3">Nama Pemohon</th>
                <th className="px-3 py-3 font-mono">NIK</th>
                <th className="px-3 py-3">Desa</th>
                <th className="px-3 py-3">Kp/RT/RW</th>
                <th className="px-3 py-3">Keterangan</th>
                <th className="px-3 py-3 text-center w-40">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {displayedRecords.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-4 py-8 text-center text-slate-400">
                    Tidak ada data dalam buku register ini.
                  </td>
                </tr>
              ) : (
                displayedRecords.map((rec, index) => (
                  <tr 
                    key={rec.id} 
                    className={`hover:bg-slate-50/80 transition-colors ${
                      selectedRecordIds.includes(rec.id) ? 'bg-emerald-50/40' : ''
                    }`}
                  >
                    <td className="px-3 py-3 text-center">
                      <input
                        type="checkbox"
                        id={`checkbox-select-${rec.id}`}
                        checked={selectedRecordIds.includes(rec.id)}
                        onChange={() => handleToggleSelectRecord(rec.id)}
                        className="rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer w-3.5 h-3.5"
                      />
                    </td>
                    <td className="px-3 py-3 text-center text-slate-400 font-medium">
                      {index + 1}
                    </td>
                    <td className="px-3 py-3 text-slate-600 whitespace-nowrap">
                      {rec.tanggal}
                    </td>
                    <td className="px-3 py-3 font-mono font-semibold text-emerald-800 whitespace-nowrap">
                      {rec.nomorRegistrasi}
                    </td>
                    <td className="px-3 py-3 font-medium text-slate-800">
                      {rec.perihal || rec.namaPelayanan}
                    </td>
                    <td className="px-3 py-3 font-semibold text-slate-900 whitespace-nowrap">
                      {rec.namaPemohon}
                    </td>
                    <td className="px-3 py-3 font-mono text-slate-600 whitespace-nowrap">
                      {rec.nik || '-'}
                    </td>
                    <td className="px-3 py-3 text-slate-700 whitespace-nowrap">
                      {rec.namaDesa}
                    </td>
                    <td className="px-3 py-3 text-slate-600 whitespace-nowrap">
                      {rec.alamat || '-'}
                    </td>
                    <td className="px-3 py-3 text-slate-500 max-w-xs">
                      <div className="truncate">{rec.keterangan || '-'}</div>
                      {rec.linkGoogleDrive && (
                        <div className="mt-1">
                          <a
                            href={rec.linkGoogleDrive.startsWith('http') ? rec.linkGoogleDrive : `https://${rec.linkGoogleDrive}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 hover:text-emerald-800 hover:underline bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 transition-colors"
                            title={rec.linkGoogleDrive}
                          >
                            <Link2 className="w-3 h-3" />
                            <span className="truncate max-w-[130px]">Google Drive</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-3 text-center whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          id={`btn-cetak-bukti-${rec.id}`}
                          type="button"
                          onClick={() => setBuktiRecord(rec)}
                          title="Cetak Bukti Serah Terima Dokumen"
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-emerald-700 hover:text-white bg-emerald-50 hover:bg-emerald-600 border border-emerald-300 hover:border-emerald-600 rounded transition-all cursor-pointer whitespace-nowrap shadow-2xs"
                        >
                          <FileText className="w-3 h-3" />
                          <span>Cetak Bukti</span>
                        </button>
                        <button
                          id={`btn-edit-rec-${rec.id}`}
                          onClick={() => handleEditClick(rec)}
                          title="Edit register"
                          className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          id={`btn-delete-rec-${rec.id}`}
                          onClick={() => handleDeleteClick(rec)}
                          title="Hapus data register"
                          className="p-1 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PRINT PREVIEW MODAL */}
      {isPrintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Printer className="w-4 h-4 text-emerald-700" />
                <h3 className="text-sm font-bold text-slate-800">
                  Pratinjau Cetak Buku Register — {getRegisterTitle(activeRegisterSeksi)}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  id="btn-cetak-dokumen-register"
                  type="button"
                  onClick={() => {
                    downloadBukuRegisterPDF({
                      seksiTitle: getRegisterTitle(activeRegisterSeksi),
                      seksiName: activeRegisterSeksi,
                      records: displayedRecords,
                    });
                  }}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                  title="Klik untuk otomatis mengunduh file dokumen PDF Buku Register"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Cetak Dokumen</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-2.5 py-1.5 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Buka dialog printer browser"
                >
                  <Printer className="w-3.5 h-3.5 text-slate-500" />
                  <span className="hidden sm:inline">Dialog Printer</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-300 text-slate-700 rounded-lg text-xs hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>

            {/* Printable Content Body */}
            <div className="p-8 overflow-y-auto print:p-0 bg-white text-slate-900">
              {/* Official Letterhead */}
              <div className="flex items-center gap-4 border-b-2 border-slate-900 pb-3 mb-6">
                <img 
                  src="/logo-kabupaten-bekasi.svg" 
                  alt="Logo Kabupaten Bekasi" 
                  className="w-16 h-16 sm:w-20 sm:h-20 object-contain shrink-0"
                  onError={(e) => {
                    e.currentTarget.src = '/logo-kabupaten-bekasi.png';
                  }}
                />
                <div className="flex-1 text-center">
                  <h2 className="text-sm font-bold uppercase tracking-wider">Pemerintah Kabupaten Bekasi</h2>
                  <h1 className="text-lg font-extrabold uppercase tracking-wide">Kecamatan Sukatani</h1>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630
                  </p>
                  <h3 className="text-sm font-bold uppercase mt-2 underline tracking-wide">
                    {getRegisterTitle(activeRegisterSeksi)}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Tahun Anggaran 2026
                  </p>
                </div>
                <div className="w-16 sm:w-20 shrink-0 hidden sm:block" />
              </div>

              {/* Table in Print Preview */}
              <table className="w-full border-collapse border border-slate-300 text-[11px]">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-300 px-2 py-1.5 text-center w-8">No</th>
                    <th className="border border-slate-300 px-2 py-1.5 w-20">Tanggal</th>
                    <th className="border border-slate-300 px-2 py-1.5 w-36">No. Registrasi</th>
                    <th className="border border-slate-300 px-2 py-1.5">Perihal</th>
                    <th className="border border-slate-300 px-2 py-1.5">Pemohon</th>
                    <th className="border border-slate-300 px-2 py-1.5 font-mono">NIK</th>
                    <th className="border border-slate-300 px-2 py-1.5">Desa</th>
                    <th className="border border-slate-300 px-2 py-1.5">Kp/RT/RW</th>
                    <th className="border border-slate-300 px-2 py-1.5">Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                  {displayedRecords.map((r, i) => (
                    <tr key={r.id}>
                      <td className="border border-slate-300 px-2 py-1 text-center">{i + 1}</td>
                      <td className="border border-slate-300 px-2 py-1 whitespace-nowrap">{r.tanggal}</td>
                      <td className="border border-slate-300 px-2 py-1 font-mono font-medium">{r.nomorRegistrasi}</td>
                      <td className="border border-slate-300 px-2 py-1">{r.perihal || r.namaPelayanan}</td>
                      <td className="border border-slate-300 px-2 py-1 font-medium">{r.namaPemohon}</td>
                      <td className="border border-slate-300 px-2 py-1 font-mono">{r.nik}</td>
                      <td className="border border-slate-300 px-2 py-1">{r.namaDesa}</td>
                      <td className="border border-slate-300 px-2 py-1">{r.alamat || '-'}</td>
                      <td className="border border-slate-300 px-2 py-1 text-slate-600">{r.keterangan || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Signature block */}
              <div className="mt-12 flex justify-end text-xs">
                <div className="text-center w-64">
                  <p>Sukatani, {tanggal}</p>
                  <p className="mt-1 font-semibold">Petugas Registrasi Pelayanan,</p>
                  <div className="h-16" />
                  <p className="font-bold underline uppercase">{currentUser.name}</p>
                  <p className="text-[10px] text-slate-500">NIP. 19850412 201001 1 012</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI HAPUS DATA REGISTER TUNGGAL */}
      {recordToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900 text-center">
                Hapus Data Buku Register?
              </h3>
              <p className="text-xs text-slate-500 text-center mt-1">
                Data pelayanan ini akan dihapus secara permanen dari basis data dan buku register.
              </p>

              {/* Record Summary Card */}
              <div className="mt-4 p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="text-slate-500 font-medium">Nomor Registrasi:</span>
                  <span className="font-mono font-bold text-emerald-800 bg-emerald-100/60 px-2 py-0.5 rounded border border-emerald-300">
                    {recordToDelete.nomorRegistrasi}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Nama Pemohon:</span>
                  <span className="font-semibold text-slate-900">{recordToDelete.namaPemohon}</span>
                </div>
                {recordToDelete.nik && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">NIK:</span>
                    <span className="font-mono text-slate-700">{recordToDelete.nik}</span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Perihal / Layanan:</span>
                  <span className="font-medium text-slate-800 text-right max-w-[200px] truncate">
                    {recordToDelete.perihal || recordToDelete.namaPelayanan}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Desa Asal:</span>
                  <span className="text-slate-700">Desa {recordToDelete.namaDesa}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Tanggal Register:</span>
                  <span className="text-slate-700">{recordToDelete.tanggal}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex items-center gap-3">
                <button
                  id="btn-cancel-delete-modal"
                  type="button"
                  onClick={() => setRecordToDelete(null)}
                  className="flex-1 py-2.5 px-4 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  id="btn-confirm-delete-modal"
                  type="button"
                  onClick={handleConfirmDeleteSingle}
                  className="flex-1 py-2.5 px-4 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Ya, Hapus Data</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI HAPUS MASSAL (BULK DELETE) */}
      {isBulkDeleteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900 text-center">
                Hapus {selectedRecordIds.length} Data Terpilih?
              </h3>
              <p className="text-xs text-slate-500 text-center mt-1">
                Semua <strong>{selectedRecordIds.length}</strong> data registrasi yang ditandai akan dihapus sekaligus dari Buku Register dan basis data. Tindakan ini tidak dapat dibatalkan.
              </p>

              <div className="mt-6 flex items-center gap-3">
                <button
                  id="btn-cancel-bulk-delete"
                  type="button"
                  onClick={() => setIsBulkDeleteOpen(false)}
                  className="flex-1 py-2.5 px-4 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  id="btn-confirm-bulk-delete"
                  type="button"
                  onClick={handleConfirmBulkDelete}
                  className="flex-1 py-2.5 px-4 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Hapus Semua ({selectedRecordIds.length})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL CETAK BUKTI SERAH TERIMA DOKUMEN */}
      {buktiRecord && (
        <BuktiSerahTerimaModal
          record={buktiRecord}
          onClose={() => setBuktiRecord(null)}
        />
      )}
    </div>
  );
};
