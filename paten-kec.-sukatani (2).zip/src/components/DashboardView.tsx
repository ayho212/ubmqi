import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SeksiType } from '../types';
import { 
  ClipboardList, 
  Calendar, 
  TrendingUp, 
  Layers, 
  Clock, 
  ArrowUpRight,
  PlusCircle,
  FileCheck,
  Building,
  BarChart3,
  MapPin,
  ChevronRight,
  Cloud,
  RefreshCw,
  Wifi,
  WifiOff,
  CheckCircle2,
  Server
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const { 
    records, 
    jenisPelayananList, 
    desaList, 
    currentUser, 
    isAdmin, 
    getUserSeksi,
    setActiveTab,
    cloudSyncStatus,
    isOnline,
    lastSyncTime,
    isMigrating,
    forceCloudSync
  } = useApp();

  const userSeksi = getUserSeksi();

  // Selected service for monthly trend visualization
  const [trendServiceId, setTrendServiceId] = useState<string>('ALL');

  // Filter records based on role:
  // Admin sees all, Seksi user sees only their seksi
  const accessibleRecords = isAdmin
    ? records
    : records.filter((r) => r.seksi === userSeksi);

  const accessibleServices = isAdmin
    ? jenisPelayananList
    : jenisPelayananList.filter((j) => j.seksi === userSeksi);

  // Dynamic Time calculations (robust timezone & local date matching)
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth(); // 0-indexed (0 = Jan, 8 = Sep)
  const currentMonthNumber = currentMonth + 1; // 1-indexed (1-12)
  const currentDate = now.getDate();

  const monthNamesIndo = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const currentMonthName = monthNamesIndo[currentMonth];

  // Helper to extract year, month, date cleanly from ISO 'YYYY-MM-DD' or full ISO string
  const parseRecordDate = (tanggalStr: string) => {
    if (!tanggalStr) return null;
    const parts = tanggalStr.split('T')[0].split('-');
    if (parts.length === 3) {
      const y = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10) - 1; // 0-indexed
      const d = parseInt(parts[2], 10);
      if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
        return { year: y, month: m, date: d };
      }
    }
    const dt = new Date(tanggalStr);
    if (!isNaN(dt.getTime())) {
      return { year: dt.getFullYear(), month: dt.getMonth(), date: dt.getDate() };
    }
    return null;
  };

  // Accurate counts matching accessible records
  const todayCount = accessibleRecords.filter(r => {
    const parsed = parseRecordDate(r.tanggal);
    if (!parsed) return false;
    return parsed.year === currentYear && parsed.month === currentMonth && parsed.date === currentDate;
  }).length;

  const monthCount = accessibleRecords.filter(r => {
    const parsed = parseRecordDate(r.tanggal);
    if (!parsed) return false;
    return parsed.year === currentYear && parsed.month === currentMonth;
  }).length;

  const yearCount = accessibleRecords.filter(r => {
    const parsed = parseRecordDate(r.tanggal);
    if (!parsed) return false;
    return parsed.year === currentYear;
  }).length;

  const displayHariIni = todayCount;
  const displayBulanIni = monthCount;
  const displayTahunIni = yearCount;

  // Breakdown per Seksi
  const seksiList: { seksi: SeksiType; label: string; color: string }[] = [
    { seksi: 'Yanlik', label: 'Pelayanan Publik (Yanlik)', color: 'bg-emerald-600' },
    { seksi: 'Pemerintahan', label: 'Pemerintahan & Pertanahan', color: 'bg-blue-600' },
    { seksi: 'Ekbang', label: 'Ekonomi & Pembangunan', color: 'bg-amber-600' },
    { seksi: 'PMD', label: 'Pemberdayaan Masyarakat (PMD)', color: 'bg-purple-600' },
    { seksi: 'Trantib', label: 'Ketenteraman & Ketertiban', color: 'bg-rose-600' },
  ];

  // Helper to determine record seksi reliably
  const getRecordSeksi = (r: (typeof records)[0]): SeksiType => {
    if (r.seksi) return r.seksi;
    const srv = jenisPelayananList.find(j => j.id === r.jenisPelayananId);
    return srv ? srv.seksi : 'Yanlik';
  };

  const dynamicSeksiCounts = seksiList.map(item => {
    const realCount = records.filter(r => getRecordSeksi(r) === item.seksi).length;
    return {
      ...item,
      count: realCount,
    };
  });

  const totalAllSeksi = dynamicSeksiCounts.reduce((acc, s) => acc + s.count, 0);
  const maxSeksiCount = Math.max(...dynamicSeksiCounts.map(s => s.count), 1);

  // Breakdown per Desa (Widget Statistik Surat Keluar per Desa)
  // Clean matching by desaId or normalized desa name
  const desaStats = desaList.map((desa) => {
    const targetName = desa.namaDesa.trim().toLowerCase();
    const dynamicCount = accessibleRecords.filter(r => {
      if (r.desaId && r.desaId === desa.id) return true;
      if (r.namaDesa) {
        const rName = r.namaDesa.trim().toLowerCase();
        return rName === targetName || rName.includes(targetName) || targetName.includes(rName);
      }
      return false;
    }).length;

    return {
      id: desa.id,
      namaDesa: desa.namaDesa,
      kodeDesa: desa.kodeDesa,
      count: dynamicCount,
    };
  }).sort((a, b) => b.count - a.count);

  const totalSuratDesa = desaStats.reduce((acc, d) => acc + d.count, 0);
  const maxDesaCount = Math.max(...desaStats.map(d => d.count), 1);

  // Monthly trend calculations (Januari - Desember tahun berjalan) per jenis permohonan pelayanan
  const monthsAbbr = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  const monthlyTrendData = monthsAbbr.map((mName, mIdx) => {
    const mNum = mIdx + 1; // 1-12
    
    const recCount = accessibleRecords.filter(r => {
      const isMatchingService = trendServiceId === 'ALL' || r.jenisPelayananId === trendServiceId;
      if (!isMatchingService) return false;

      const parsed = parseRecordDate(r.tanggal);
      if (!parsed) return false;

      return parsed.year === currentYear && parsed.month === mIdx;
    }).length;

    return {
      month: mName,
      monthNumber: mNum,
      count: recCount,
    };
  });

  const totalMonthlyTrend = monthlyTrendData.reduce((acc, m) => acc + m.count, 0);
  const maxMonthlyVal = Math.max(...monthlyTrendData.map(m => m.count), 1);

  // Recent services list
  const recentRecords = [...accessibleRecords]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Top Banner / Heading */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider">
            <span>Pelayanan Administrasi Terpadu Kecamatan (PATEN)</span>
            <span>•</span>
            <span>Kabupaten Bekasi</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mt-1">
            Dashboard Utama
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {isAdmin 
              ? 'Monitoring ringkasan pelayanan seluruh seksi bidang dan per desa di Kecamatan Sukatani.' 
              : `Monitoring ringkasan pelayanan khusus Seksi ${userSeksi} di Kecamatan Sukatani.`}
          </p>
        </div>
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            id="btn-quick-input"
            onClick={() => setActiveTab('input-pelayanan')}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition-colors shadow-sm cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Input Pelayanan Baru</span>
          </button>
        </div>
      </div>

      {/* Cloud Database Synchronization Indicator Banner */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 border border-emerald-200/80 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-white border border-emerald-200 text-emerald-600 flex items-center justify-center shrink-0 shadow-xs">
            <Cloud className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-slate-800">
                Basis Data Daring Cloud (Google Cloud Firestore)
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Tersinkronisasi Real-Time Antarperangkat
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Data tersimpan terpusat di server cloud. Perubahan data di loket atau gawai ini otomatis diperbarui di seluruh perangkat lain tanpa perlu refresh.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          <button
            type="button"
            disabled={isMigrating}
            onClick={() => forceCloudSync()}
            title="Klik untuk menyinkronkan data dengan basis data cloud"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 shadow-2xs transition-all cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-emerald-600 ${isMigrating ? 'animate-spin' : ''}`} />
            <span>{isMigrating ? 'Menyinkronkan...' : 'Sinkronkan'}</span>
            {lastSyncTime && (
              <span className="text-[10px] text-slate-400 font-mono hidden md:inline">
                ({lastSyncTime})
              </span>
            )}
          </button>
        </div>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Hari Ini */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Hari Ini</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ClipboardList className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-800 tracking-tight">
              {displayHariIni.toLocaleString('id-ID')}
            </div>
            <div className="flex items-center gap-1 text-xs text-emerald-600 font-medium mt-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Surat teregistrasi hari ini</span>
            </div>
          </div>
        </div>

        {/* Bulan Ini */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Bulan Ini</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-800 tracking-tight">
              {displayBulanIni.toLocaleString('id-ID')}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Periode {currentMonthName} {currentYear}
            </div>
          </div>
        </div>

        {/* Tahun Ini */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Tahun Ini</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-800 tracking-tight">
              {displayTahunIni.toLocaleString('id-ID')}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Tahun Anggaran {currentYear}
            </div>
          </div>
        </div>

        {/* Jenis Layanan */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Jenis Layanan</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-800 tracking-tight">
              {accessibleServices.length}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {isAdmin ? 'Total 5 seksi bidang' : `Seksi ${userSeksi}`}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION: Widget Statistik Total Surat Keluar per Seksi dan per Desa */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Widget 1: Total Surat Keluar per Seksi */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-800">
                      Total Surat Keluar per Seksi
                    </h2>
                    <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      Total: {totalAllSeksi}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Kuantitas berkas surat per seksi bidang
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('laporan-grafik')}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-medium hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Lihat Rekap</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            {isAdmin ? (
              <div className="space-y-3.5 mt-2">
                {dynamicSeksiCounts.map((item) => {
                  const percentage = Math.round((item.count / maxSeksiCount) * 100);
                  return (
                    <div key={item.seksi} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-medium text-slate-700">
                        <span className="font-semibold">{item.label}</span>
                        <span className="text-slate-900 font-bold font-mono">{item.count} surat</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${item.color}`}
                          style={{ width: `${Math.min(percentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="space-y-3 mt-2">
                <p className="text-xs text-slate-500">
                  Rincian layanan pada Seksi {userSeksi}:
                </p>
                {accessibleServices.slice(0, 4).map((srv) => {
                  const srvCount = accessibleRecords.filter(r => r.jenisPelayananId === srv.id).length;
                  return (
                    <div key={srv.id} className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between">
                      <div className="pr-2">
                        <p className="text-xs font-semibold text-slate-800 line-clamp-1">{srv.namaPelayanan}</p>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">{srv.kode}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-xs font-bold text-emerald-700 font-mono">{srvCount}</span>
                        <span className="text-[10px] text-slate-500 ml-1">surat</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="mt-5 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Seksi Bidang: 5 Unit Kerja</span>
            <span className="text-emerald-700 font-medium">Data Terverifikasi</span>
          </div>
        </div>

        {/* Widget 2: Total Surat Keluar per Desa */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-800">
                      Total Surat Keluar per Desa
                    </h2>
                    <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                      Total: {totalSuratDesa}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Distribusi permohonan dari {desaList.length} desa se-Kecamatan Sukatani
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('laporan-grafik')}
                className="text-xs text-blue-600 hover:text-blue-700 font-medium hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Filter Desa</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              {desaStats.map((desa) => {
                const percentage = Math.round((desa.count / maxDesaCount) * 100);
                return (
                  <div key={desa.id} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-medium text-slate-700">
                      <span className="font-semibold text-slate-800">Desa {desa.namaDesa}</span>
                      <span className="text-slate-900 font-bold font-mono">{desa.count} surat</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className="h-full rounded-full bg-blue-600 transition-all duration-500"
                        style={{ width: `${Math.min(percentage, 100)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="mt-5 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Cakupan: Seluruh Desa Kecamatan Sukatani</span>
            <span className="text-blue-700 font-medium">Total {desaList.length} Desa Terdata</span>
          </div>
        </div>
      </div>

      {/* SECTION: Visualisasi Grafik Tren Bulanan per Jenis Permohonan Pelayanan */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-800">
                  Grafik Tren Bulanan Pelayanan
                </h2>
                <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  Total Terakumulasi: {totalMonthlyTrend} Surat
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Visualisasi fluktuasi permohonan pelayanan (Januari - Desember {currentYear})
              </p>
            </div>
          </div>

          {/* Filter per Jenis Pelayanan */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Filter Layanan:</span>
            <select
              id="filter-trend-service"
              value={trendServiceId}
              onChange={(e) => setTrendServiceId(e.target.value)}
              className="text-xs border border-slate-300 rounded-lg px-3 py-1.5 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 max-w-xs truncate"
            >
              <option value="ALL">Semua Jenis Permohonan</option>
              {accessibleServices.map((srv) => (
                <option key={srv.id} value={srv.id}>
                  [{srv.seksi}] {srv.namaPelayanan}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* 12-Month Bar Chart */}
        <div className="grid grid-cols-12 gap-1.5 sm:gap-3 items-end h-56 pt-6 px-1">
          {monthlyTrendData.map((item) => {
            const heightPercent = maxMonthlyVal > 0 ? Math.max(Math.round((item.count / maxMonthlyVal) * 100), 6) : 6;
            const isCurrentMonth = item.monthNumber === currentMonthNumber;

            return (
              <div key={item.month} className="flex flex-col items-center h-full justify-end group">
                {/* Count tooltip on top */}
                <span className="text-[10px] font-bold text-slate-600 mb-1 opacity-80 group-hover:opacity-100 font-mono transition-opacity">
                  {item.count}
                </span>

                {/* Vertical Bar */}
                <div className="w-full max-w-[36px] bg-slate-100 rounded-t-md h-full flex items-end overflow-hidden p-0.5">
                  <div
                    className={`w-full rounded-t-sm transition-all duration-700 group-hover:brightness-110 ${
                      isCurrentMonth
                        ? 'bg-emerald-600'
                        : item.monthNumber < currentMonthNumber
                        ? 'bg-emerald-500/75'
                        : 'bg-slate-300'
                    }`}
                    style={{ height: `${heightPercent}%` }}
                  />
                </div>

                {/* Month Label */}
                <span className={`text-[11px] mt-2 font-medium ${isCurrentMonth ? 'font-bold text-emerald-700' : 'text-slate-500'}`}>
                  {item.month}
                </span>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-600 inline-block" /> Bulan Berjalan ({currentMonthName})
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500/75 inline-block" /> Realisasi Sebelumnya
            </span>
          </div>
          <span className="text-slate-400 italic">
            Visualisasi tren permohonan dokumen pelayanan masyarakat
          </span>
        </div>
      </div>

      {/* SECTION: Pelayanan Terbaru */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-800">
              Pelayanan Terbaru
            </h2>
            <p className="text-xs text-slate-500">
              Daftar registrasi berkas pelayanan yang tercatat paling akhir di sistem
            </p>
          </div>
          <button
            onClick={() => setActiveTab('input-pelayanan')}
            className="text-xs text-emerald-600 hover:text-emerald-700 font-medium hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Buka Buku Register</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {recentRecords.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-xs">
            Belum ada berkas pelayanan yang dicatat.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentRecords.map((rec) => {
              const timeStr = rec.createdAt ? new Date(rec.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '10:00';
              return (
                <div key={rec.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    <div className="w-8 h-8 rounded bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                      <FileCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-800 line-clamp-1">
                        {rec.namaPelayanan}
                      </p>
                      <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-0.5">
                        <span className="font-mono font-semibold text-emerald-700">{rec.nomorRegistrasi}</span>
                        <span>•</span>
                        <span className="font-medium text-slate-700">{rec.namaPemohon}</span>
                        <span>•</span>
                        <span>Desa {rec.namaDesa}</span>
                        {rec.alamat && (
                          <>
                            <span>•</span>
                            <span className="text-slate-400">{rec.alamat}</span>
                          </>
                        )}
                      </div>
                      {rec.perihal && (
                        <p className="text-[11px] text-slate-500 italic mt-0.5">
                          Perihal: {rec.perihal}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="text-left sm:text-right shrink-0 pl-10 sm:pl-0">
                    <div className="text-xs font-semibold text-slate-600 flex items-center sm:justify-end gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{rec.tanggal} ({timeStr})</span>
                    </div>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium mt-1 inline-block">
                      Seksi {rec.seksi}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
