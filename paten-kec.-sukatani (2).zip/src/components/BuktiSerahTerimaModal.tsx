import React from 'react';
import { PelayananRecord } from '../types';
import { downloadBuktiSerahTerimaPDF } from '../utils/exportPdf';
import { 
  FileText, 
  Printer, 
  Download, 
  X,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

interface BuktiSerahTerimaModalProps {
  record: PelayananRecord;
  onClose: () => void;
}

export const BuktiSerahTerimaModal: React.FC<BuktiSerahTerimaModalProps> = ({
  record,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    downloadBuktiSerahTerimaPDF(record);
  };

  const todayStr = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header (Non-print) */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0 no-print">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Bukti Serah Terima Dokumen
              </h3>
              <p className="text-[11px] text-emerald-800 font-mono font-medium">
                No. Reg: {record.nomorRegistrasi}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="btn-download-pdf-bukti"
              type="button"
              onClick={handleDownload}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
              title="Unduh file PDF resmi bukti serah terima dokumen"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh PDF</span>
            </button>
            <button
              id="btn-print-bukti-printer"
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
              title="Buka dialog printer browser"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Cetak</span>
            </button>
            <button
              id="btn-close-bukti-modal"
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer"
              title="Tutup"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div className="p-6 sm:p-8 overflow-y-auto bg-white text-slate-900 printable-area text-xs">
          {/* Kop Surat Resmi */}
          <div className="flex items-center gap-4 border-b-2 border-slate-900 pb-3 mb-4">
            <img 
              src="/logo-kabupaten-bekasi.svg" 
              alt="Logo Kabupaten Bekasi" 
              className="w-16 h-16 sm:w-18 sm:h-18 object-contain shrink-0"
              onError={(e) => {
                e.currentTarget.src = '/logo-kabupaten-bekasi.png';
              }}
            />
            <div className="flex-1 text-center">
              <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-800">
                Pemerintah Kabupaten Bekasi
              </h2>
              <h1 className="text-base sm:text-lg font-extrabold uppercase tracking-wide text-slate-950">
                Kecamatan Sukatani
              </h1>
              <p className="text-[10px] text-slate-600 mt-0.5">
                Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630
              </p>
              <p className="text-[9px] text-slate-500">
                Website: kecamatansukatani.bekasikab.go.id | Email: kecamatan.sukatani@bekasikab.go.id
              </p>
            </div>
            <div className="w-16 sm:w-18 shrink-0 hidden sm:block" />
          </div>

          {/* Document Title */}
          <div className="text-center my-3">
            <h3 className="text-xs sm:text-sm font-extrabold uppercase tracking-wide text-slate-900 underline decoration-slate-400">
              Tanda Bukti Pendaftaran & Serah Terima Dokumen
            </h3>
            <p className="text-[10px] text-slate-600 mt-0.5 uppercase font-medium">
              Pelayanan Administrasi Terpadu Kecamatan (PATEN)
            </p>
          </div>

          {/* Nomor Registrasi Highlight Banner */}
          <div className="bg-emerald-50/80 border border-emerald-300 rounded-xl p-3 my-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
                Nomor Registrasi Pelayanan
              </span>
              <span className="font-mono font-extrabold text-sm sm:text-base text-emerald-900 tracking-tight">
                {record.nomorRegistrasi}
              </span>
            </div>
            <div className="sm:text-right">
              <span className="text-[10px] text-emerald-700 block">Tanggal Registrasi:</span>
              <span className="text-xs font-bold text-slate-800 font-mono">
                {record.tanggal}
              </span>
            </div>
          </div>

          {/* Rincian Detail Layanan & Pemohon */}
          <div className="border border-slate-200 rounded-xl overflow-hidden my-3">
            <div className="bg-slate-100/80 px-3 py-1.5 border-b border-slate-200 font-bold text-slate-700 text-[11px] uppercase tracking-wider flex items-center justify-between">
              <span>Rincian Permohonan Pelayanan</span>
              <span className="flex items-center gap-1 text-[10px] text-emerald-700 font-semibold lowercase first-letter:uppercase">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                Terdaftar di Loket PATEN
              </span>
            </div>
            <table className="w-full text-left text-xs border-collapse">
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 w-44 bg-slate-50/50">Nama Pemohon</td>
                  <td className="py-2 px-3 font-bold text-slate-900">{record.namaPemohon}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">NIK (No. KTP)</td>
                  <td className="py-2 px-3 font-mono text-slate-800">{record.nik || '-'}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Desa Asal</td>
                  <td className="py-2 px-3 font-medium text-slate-800">Desa {record.namaDesa}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Alamat / Kp / RT / RW</td>
                  <td className="py-2 px-3 text-slate-700">{record.alamat || '-'}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Seksi Pelayanan</td>
                  <td className="py-2 px-3 text-slate-800">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                      Seksi {record.seksi}
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Jenis Layanan</td>
                  <td className="py-2 px-3 font-medium text-slate-800">{record.namaPelayanan}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Perihal / Keperluan</td>
                  <td className="py-2 px-3 font-medium text-slate-900">{record.perihal || record.namaPelayanan}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Status & Kelengkapan</td>
                  <td className="py-2 px-3 text-slate-700">
                    {record.keterangan || 'Berkas persyaratan administrasi dinyatakan lengkap dan diterima loket.'}
                  </td>
                </tr>
                {record.linkGoogleDrive && (
                  <tr>
                    <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Upload Dokumen (Google Drive)</td>
                    <td className="py-2 px-3">
                      <a 
                        href={record.linkGoogleDrive.startsWith('http') ? record.linkGoogleDrive : `https://${record.linkGoogleDrive}`}
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-emerald-700 hover:text-emerald-800 hover:underline font-mono text-[11px] inline-flex items-center gap-1 break-all font-medium"
                      >
                        <span>{record.linkGoogleDrive}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </td>
                  </tr>
                )}
                <tr>
                  <td className="py-2 px-3 font-semibold text-slate-600 bg-slate-50/50">Petugas Penerima Loket</td>
                  <td className="py-2 px-3 font-medium text-slate-800">{record.petugas}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Klausul Ketentuan Serah Terima Dokumen */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 my-3 text-[10px] text-slate-600 space-y-1">
            <p className="font-bold text-slate-700 uppercase tracking-wide">
              Ketentuan & Informasi Pemohon:
            </p>
            <p>1. Tanda bukti pendaftaran/serah terima berkas ini merupakan dokumen sah yang diterbitkan oleh Loket PATEN Kecamatan Sukatani.</p>
            <p>2. Harap simpan dan bawa lembar tanda bukti ini saat pengambilan fisik dokumen yang telah selesai diproses atau dilegalisasi.</p>
            <p>3. Pemohon dapat melakukan konfirmasi perkembangan status berkas kepada petugas loket dengan menyebutkan Nomor Registrasi di atas.</p>
          </div>

          {/* Tanda Tangan Serah Terima Dua Pihak */}
          <div className="mt-6 pt-2 text-xs">
            <div className="text-right text-slate-600 mb-2 font-medium">
              Sukatani, {todayStr}
            </div>
            <div className="grid grid-cols-2 gap-8 text-center pt-2">
              <div>
                <p className="text-slate-600 font-medium">Yang Menyerahkan (Pemohon),</p>
                <div className="h-16 flex items-end justify-center">
                  <p className="text-slate-400 text-[10px]">( ................................................ )</p>
                </div>
                <p className="font-bold text-slate-900 underline mt-1">{record.namaPemohon}</p>
              </div>
              <div>
                <p className="text-slate-600 font-medium">Yang Menerima (Petugas PATEN),</p>
                <div className="h-16 flex items-end justify-center">
                  <p className="text-slate-400 text-[10px]">( ................................................ )</p>
                </div>
                <p className="font-bold text-slate-900 underline mt-1">{record.petugas}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer (Non-print) */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 no-print">
          <span>Gunakan tombol "Unduh PDF" untuk menyimpan file digital atau "Cetak" untuk printer.</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-semibold transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
