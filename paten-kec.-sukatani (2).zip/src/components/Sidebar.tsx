import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  LayoutDashboard, 
  FileEdit, 
  BarChart3, 
  Database, 
  Users, 
  ShieldCheck,
  UserCheck,
  LogOut
} from 'lucide-react';
import { ActiveTab } from '../types';

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen = false, onClose }) => {
  const { activeTab, setActiveTab, currentUser, isAdmin, getUserSeksi, logout } = useApp();
  const userSeksi = getUserSeksi();

  const handleNavClick = (tabId: ActiveTab) => {
    setActiveTab(tabId);
    if (onClose) onClose();
  };

  const mainNavItems: { id: ActiveTab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'input-pelayanan', label: 'Input Pelayanan', icon: FileEdit },
    { id: 'laporan-grafik', label: 'Laporan & Grafik', icon: BarChart3 },
  ];

  const adminNavItems: { id: ActiveTab; label: string; icon: React.ElementType }[] = [
    { id: 'master-data', label: 'Master Data', icon: Database },
    { id: 'kelola-user', label: 'Kelola User', icon: Users },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 lg:static lg:z-auto w-64 bg-slate-900 text-slate-200 flex flex-col shrink-0 border-r border-slate-800 select-none transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
      {/* App Branding block inside Sidebar */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-white/95 p-1 flex items-center justify-center shrink-0">
            <img 
              src="/logo-kabupaten-bekasi.svg" 
              alt="Logo Kabupaten Bekasi" 
              className="w-full h-full object-contain"
              onError={(e) => {
                e.currentTarget.src = '/logo-kabupaten-bekasi.png';
              }}
            />
          </div>
          <div>
            <span className="text-xs font-bold text-white tracking-wider uppercase block leading-tight">
              PATEN Kec. Sukatani
            </span>
            <span className="text-[10px] text-emerald-400 font-medium">Kabupaten Bekasi</span>
          </div>
        </div>
        <div className="mt-2 text-xs font-medium text-slate-300 bg-slate-800/80 px-2.5 py-1.5 rounded-md flex items-center justify-between">
          <span className="text-slate-400">Hak Akses:</span>
          <span className="text-emerald-400 font-semibold">
            {currentUser.level === 'L1' ? 'Administrator' : `Seksi ${userSeksi || currentUser.level}`}
          </span>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {mainNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}

        {/* Admin Navigation Group */}
        {isAdmin && (
          <div className="pt-5 mt-4 border-t border-slate-800">
            <div className="px-3 pb-2 text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Menu Admin</span>
            </div>
            {adminNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </nav>

      {/* User Information Footer */}
      <div className="p-3 border-t border-slate-800 space-y-2">
        <div className="bg-slate-800/60 rounded-lg p-2.5 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold shrink-0">
              <UserCheck className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <p className="font-medium text-slate-200 truncate">{currentUser.name}</p>
              <p className="text-[11px] text-slate-400 truncate">{currentUser.email}</p>
            </div>
          </div>
          <button
            onClick={() => logout()}
            title="Keluar Sesi (Logout)"
            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700/50 rounded transition-colors shrink-0 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
    </>
  );
};
