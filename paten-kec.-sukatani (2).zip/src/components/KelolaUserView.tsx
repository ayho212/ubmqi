import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User, UserLevel } from '../types';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  Trash2, 
  Edit3, 
  Save, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Mail, 
  Lock, 
  KeyRound,
  RotateCcw,
  Cloud
} from 'lucide-react';

export const KelolaUserView: React.FC = () => {
  const { users, addUser, updateUser, deleteUser, currentUser, isAdmin } = useApp();

  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [level, setLevel] = useState<UserLevel>('L2');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isAdmin) {
    return (
      <div className="bg-white rounded-xl p-8 border border-slate-200 text-center">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-slate-800">Akses Terbatas</h2>
        <p className="text-sm text-slate-500 mt-1">
          Halaman Pengelolaan Pengguna (User Management) hanya dapat diakses oleh Administrator Level 1.
        </p>
      </div>
    );
  }

  const getSeksiByLevel = (lvl: UserLevel) => {
    switch (lvl) {
      case 'L1': return undefined;
      case 'L2': return 'Yanlik' as const;
      case 'L3': return 'Pemerintahan' as const;
      case 'L4': return 'Ekbang' as const;
      case 'L5': return 'PMD' as const;
      case 'L6': return 'Trantib' as const;
    }
  };

  const getRoleLabel = (lvl: UserLevel, seksi?: string) => {
    switch (lvl) {
      case 'L1': return 'Level 1: Administrator';
      case 'L2': return 'Level 2: Seksi Pelayanan Publik (Yanlik)';
      case 'L3': return 'Level 3: Seksi Pemerintahan & Pertanahan';
      case 'L4': return 'Level 4: Seksi Ekonomi & Pembangunan';
      case 'L5': return 'Level 5: Seksi Pemberdayaan Masyarakat (PMD)';
      case 'L6': return 'Level 6: Seksi Ketenteraman & Ketertiban (Trantib)';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!username.trim() || !name.trim()) {
      setNotification({ type: 'error', message: 'Username dan Nama Lengkap wajib diisi.' });
      return;
    }

    if (!editingUserId && !password) {
      setNotification({ type: 'error', message: 'Kata Sandi wajib diisi untuk akun baru.' });
      return;
    }

    // Check duplicate username
    const existing = users.find(u => u.username.toLowerCase() === username.trim().toLowerCase() && u.id !== editingUserId);
    if (existing) {
      setNotification({ type: 'error', message: 'Username sudah digunakan oleh akun lain.' });
      return;
    }

    const calculatedSeksi = getSeksiByLevel(level);

    if (editingUserId) {
      const updatePayload: Partial<User> = {
        username: username.trim(),
        name: name.trim(),
        email: email.trim() || `${username.toLowerCase()}@sukatani.go.id`,
        level,
        seksi: calculatedSeksi,
      };
      if (password.trim()) {
        updatePayload.password = password.trim();
      }

      updateUser(editingUserId, updatePayload);
      setNotification({ type: 'success', message: 'Data pengguna berhasil diperbarui!' });
    } else {
      addUser({
        username: username.trim(),
        password: password.trim(),
        name: name.trim(),
        email: email.trim() || `${username.toLowerCase()}@sukatani.go.id`,
        level,
        seksi: calculatedSeksi,
        status: 'Aktif',
      });
      setNotification({ type: 'success', message: 'Akun petugas baru berhasil didaftarkan!' });
    }

    resetForm();
    setTimeout(() => setNotification(null), 3500);
  };

  const handleEdit = (u: User) => {
    setEditingUserId(u.id);
    setUsername(u.username);
    setPassword(''); // leave blank if don't want to change
    setName(u.name);
    setEmail(u.email);
    setLevel(u.level);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (u: User) => {
    if (u.id === currentUser.id) {
      setNotification({ type: 'error', message: 'Anda tidak dapat menghapus akun Anda yang sedang aktif saat ini.' });
      return;
    }

    if (window.confirm(`Hapus akun petugas "${u.name}" (${u.username})?`)) {
      deleteUser(u.id);
      setNotification({ type: 'success', message: 'Akun berhasil dihapus.' });
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const resetForm = () => {
    setEditingUserId(null);
    setUsername('');
    setPassword('');
    setName('');
    setEmail('');
    setLevel('L2');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider">
            <span>Manajemen Akses Sistem</span>
            <span>•</span>
            <span>Administrator PATEN</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mt-1">
            Pengelolaan Akun Pengguna (6 Level Akses)
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manajemen hak akses petugas seksi pelayanan: Admin (L1), Yanlik (L2), Pemerintahan (L3), Ekbang (L4), PMD (L5), Trantib (L6)
          </p>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div
          className={`p-4 rounded-xl flex items-center gap-3 text-sm font-medium ${
            notification.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Create / Edit User */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:col-span-1 h-fit">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-emerald-600" />
              <span>{editingUserId ? 'Edit Akun Petugas' : 'Tambah Akun Petugas'}</span>
            </h2>
            {editingUserId && (
              <button
                onClick={resetForm}
                className="text-xs text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                title="Batal Edit"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tingkat Hak Akses (6 Level) <span className="text-red-500">*</span>
              </label>
              <select
                id="select-user-level"
                value={level}
                onChange={(e) => setLevel(e.target.value as UserLevel)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
              >
                <option value="L1">Level 1: Administrator (Semua Seksi)</option>
                <option value="L2">Level 2: Seksi Pelayanan Publik (Yanlik)</option>
                <option value="L3">Level 3: Seksi Pemerintahan</option>
                <option value="L4">Level 4: Seksi Ekbang</option>
                <option value="L5">Level 5: Seksi PMD</option>
                <option value="L6">Level 6: Seksi Trantib</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username Akses <span className="text-red-500">*</span>
              </label>
              <input
                id="input-user-username"
                type="text"
                required
                placeholder="misal: admin, pelayanan, pemerintahan"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
                <span>Kata Sandi (Password)</span>
                {editingUserId && (
                  <span className="text-[10px] text-slate-400 font-normal">
                    Kosongkan bila tidak diubah
                  </span>
                )}
              </label>
              <div className="relative">
                <div className="absolute left-3 top-2 text-slate-400">
                  <KeyRound className="w-3.5 h-3.5" />
                </div>
                <input
                  id="input-user-password"
                  type="text"
                  required={!editingUserId}
                  placeholder={editingUserId ? 'Biarkan kosong jika tidak diubah' : 'Kata sandi akun'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-8 pr-3 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Lengkap Petugas <span className="text-red-500">*</span>
              </label>
              <input
                id="input-user-fullname"
                type="text"
                required
                placeholder="misal: Ahmad Fauzi, S.AP"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Dinas (Opsional)
              </label>
              <div className="relative">
                <div className="absolute left-3 top-2 text-slate-400">
                  <Mail className="w-3.5 h-3.5" />
                </div>
                <input
                  id="input-user-email"
                  type="email"
                  placeholder="petugas@sukatani.go.id"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                id="btn-save-user"
                type="submit"
                className="flex-1 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{editingUserId ? 'Perbarui Akun' : 'Daftarkan Akun'}</span>
              </button>
              {editingUserId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="py-2 px-3 border border-slate-300 text-slate-600 hover:bg-slate-50 text-xs font-medium rounded-lg cursor-pointer"
                >
                  Batal
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Table List of Users */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden lg:col-span-2">
          <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                Daftar Petugas & Tingkat Hak Akses
              </h3>
              <p className="text-xs text-slate-500">
                Total {users.length} akun petugas terdaftar di sistem PATEN
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 self-start sm:self-auto">
              <Cloud className="w-3.5 h-3.5 text-emerald-600" />
              <span>Tersimpan di Cloud Firestore</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="px-3 py-2.5">Tingkat Hak Akses</th>
                  <th className="px-3 py-2.5">Username</th>
                  <th className="px-3 py-2.5">Nama Petugas</th>
                  <th className="px-3 py-2.5">Email</th>
                  <th className="px-3 py-2.5 text-center w-20">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {users.map((u) => {
                  const isCurrent = u.id === currentUser.id;
                  return (
                    <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-2.5 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                          u.level === 'L1'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {u.level === 'L1' && <ShieldCheck className="w-3 h-3 text-emerald-700" />}
                          <span>{u.level} — {u.seksi ? `Seksi ${u.seksi}` : 'Admin'}</span>
                        </span>
                      </td>
                      <td className="px-3 py-2.5 font-mono font-bold text-slate-900">
                        {u.username}
                      </td>
                      <td className="px-3 py-2.5 font-medium text-slate-800">
                        <div className="flex items-center gap-1.5">
                          <span>{u.name}</span>
                          {isCurrent && (
                            <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-300 px-1 rounded font-normal">
                              Akun Anda
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-slate-500">
                        {u.email}
                      </td>
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            id={`btn-edit-user-${u.id}`}
                            onClick={() => handleEdit(u)}
                            className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                            title="Edit Akun"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            id={`btn-delete-user-${u.id}`}
                            onClick={() => handleDelete(u)}
                            disabled={isCurrent}
                            className={`p-1 rounded transition-colors cursor-pointer ${
                              isCurrent
                                ? 'text-slate-300 cursor-not-allowed'
                                : 'text-slate-500 hover:text-rose-700 hover:bg-rose-50'
                            }`}
                            title={isCurrent ? 'Tidak dapat menghapus akun sendiri' : 'Hapus Akun'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
