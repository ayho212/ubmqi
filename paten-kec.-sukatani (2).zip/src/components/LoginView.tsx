import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Lock, 
  User, 
  Eye, 
  EyeOff, 
  LogIn, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  ShieldCheck, 
  Clock, 
  HelpCircle 
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, logoutReason, clearLogoutReason, forgotPassword } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Forgot password modal
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotInput, setForgotInput] = useState('');
  const [forgotFeedback, setForgotFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    clearLogoutReason();

    if (!username.trim() || !password) {
      setErrorMessage('Username atau Password tidak sesuai');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const res = login(username, password);
      setIsLoading(false);
      if (!res.success) {
        setErrorMessage(res.message);
      }
    }, 250);
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotInput.trim()) return;
    const res = forgotPassword(forgotInput.trim());
    setForgotFeedback(res);
  };

  return (
    <div className="min-h-screen bg-slate-900/95 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Decorative ambient background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-emerald-600/10 via-emerald-800/5 to-transparent blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
        {/* Header Government Identity & Official Crest */}
        <div className="text-center">
          {/* Official Logo Display */}
          <div className="flex justify-center mb-4">
            <img 
              src="/logo-kabupaten-bekasi.svg" 
              alt="Logo Kabupaten Bekasi" 
              className="w-24 h-24 sm:w-28 sm:h-28 object-contain filter drop-shadow-2xl transition-transform duration-300 hover:scale-105"
              onError={(e) => {
                e.currentTarget.src = '/logo-kabupaten-bekasi.png';
              }}
            />
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 bg-emerald-950/80 border border-emerald-500/30 rounded-full text-emerald-300 text-xs font-semibold tracking-wider uppercase mb-2 shadow-inner">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Pemerintah Kabupaten Bekasi</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              PATEN Kec. Sukatani
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300 font-medium">
              Sistem Informasi Pelayanan Administrasi Terpadu Kecamatan
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10">
        {/* Session Timeout Banner (If previously logged out by timeout) */}
        {logoutReason && (
          <div className="mb-4 bg-amber-500/10 border border-amber-500/40 rounded-xl p-3.5 text-amber-200 text-xs flex items-start gap-2.5">
            <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-300">Pemberitahuan Sesi Keamanan</p>
              <p className="mt-0.5 leading-relaxed">{logoutReason}</p>
            </div>
          </div>
        )}

        {/* Failed Login Notification */}
        {errorMessage && (
          <div 
            id="login-error-alert"
            className="mb-4 bg-red-950/70 border border-red-500/50 rounded-xl p-3.5 text-red-200 text-xs flex items-start gap-2.5 animate-in fade-in duration-200 shadow-lg"
          >
            <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-red-300">Autentikasi Gagal</p>
              <p className="mt-0.5">{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Main Login Card */}
        <div className="bg-white rounded-2xl shadow-2xl border border-slate-200/90 overflow-hidden">
          <div className="h-1.5 bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-600" />
          <div className="bg-slate-50 border-b border-slate-100 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <h2 className="text-sm font-bold text-slate-800">Autentikasi Pengguna PATEN</h2>
            </div>
            <span className="text-[11px] font-medium bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full">
              Sesi Terproteksi
            </span>
          </div>

          <div className="p-6 sm:p-8">
            <form onSubmit={handleLogin} className="space-y-5">
              {/* Element 1: Input Username */}
              <div>
                <label 
                  htmlFor="input-username"
                  className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5"
                >
                  Input Username <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="input-username"
                    name="username"
                    type="text"
                    required
                    autoFocus
                    autoComplete="username"
                    placeholder="Masukkan Username (misal: Admin, Pelayanan)"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      if (errorMessage) setErrorMessage(null);
                    }}
                    className="block w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white font-medium transition-colors"
                  />
                </div>
              </div>

              {/* Element 2: Input Password with Show/Hide */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label 
                    htmlFor="input-password"
                    className="block text-xs font-bold text-slate-700 uppercase tracking-wider"
                  >
                    Input Password <span className="text-red-500">*</span>
                  </label>
                  <button
                    type="button"
                    id="btn-forgot-password"
                    onClick={() => {
                      setIsForgotModalOpen(true);
                      setForgotFeedback(null);
                    }}
                    className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold transition-colors cursor-pointer"
                  >
                    Lupa Password?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="input-password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="current-password"
                    placeholder="Masukkan Kata Sandi"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errorMessage) setErrorMessage(null);
                    }}
                    className="block w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white font-mono transition-colors"
                  />
                  {/* Show/Hide Password Feature */}
                  <button
                    type="button"
                    id="btn-toggle-password"
                    onClick={() => setShowPassword(!showPassword)}
                    title={showPassword ? 'Sembunyikan Kata Sandi' : 'Tampilkan Kata Sandi'}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none transition-colors cursor-pointer"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Element 3: Tombol Akses (Login & Reset/Lupa Password) */}
              <div className="pt-2 space-y-3">
                <button
                  type="submit"
                  id="btn-login"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors disabled:opacity-60 cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Memverifikasi Akses...</span>
                    </>
                  ) : (
                    <>
                      <LogIn className="w-4 h-4" />
                      <span>Masuk ke Sistem (Login)</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-5 pt-4 border-t border-slate-100 text-center">
              <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Sistem dilengkapi pembatasan Session Timeout (15 Menit Tidak Aktif)</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL: Lupa / Reset Password */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2 text-emerald-700">
                <HelpCircle className="w-5 h-5" />
                <h3 className="text-base font-bold text-slate-800">Lupa / Reset Password</h3>
              </div>
              <button
                onClick={() => setIsForgotModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-600 space-y-2 mb-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>SOP Keamanan Akun Dinas PATEN:</span>
              </p>
              <p>
                Sesuai regulasi tata kelola sistem, petugas seksi yang kehilangan kata sandi dapat melapor kepada <strong>Administrator Level 1 (Kecamatan)</strong> atau menggunakan pemulihan otomatis di bawah ini.
              </p>
            </div>

            {forgotFeedback && (
              <div className={`mb-4 p-3.5 rounded-xl text-xs flex items-start gap-2.5 ${
                forgotFeedback.success 
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-900' 
                  : 'bg-red-50 border border-red-200 text-red-900'
              }`}>
                {forgotFeedback.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <p className="font-bold">{forgotFeedback.success ? 'Berhasil' : 'Perhatian'}</p>
                  <p className="mt-0.5 leading-relaxed">{forgotFeedback.message}</p>
                </div>
              </div>
            )}

            <form onSubmit={handleForgotSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Masukkan Username atau Email Petugas:
                </label>
                <input
                  type="text"
                  required
                  placeholder="misal: Pelayanan atau yanlik@sukatani.go.id"
                  value={forgotInput}
                  onChange={(e) => setForgotInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3.5 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsForgotModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-medium rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm cursor-pointer"
                >
                  Reset ke Sandi Standar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
