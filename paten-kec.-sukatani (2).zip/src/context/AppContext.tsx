import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  writeBatch 
} from 'firebase/firestore';
import { db, testFirestoreConnection, handleFirestoreError, OperationType, sanitizeForFirestore } from '../lib/firebase';
import { 
  UserProfile, 
  Desa, 
  JenisPelayanan, 
  PelayananRecord, 
  ActiveTab, 
  SeksiType, 
  UserLevel,
  CloudSyncStatus
} from '../types';
import { 
  INITIAL_USERS, 
  INITIAL_DESA, 
  INITIAL_JENIS_PELAYANAN, 
  INITIAL_PELAYANAN_RECORDS, 
  toRomanNumeral 
} from '../data/seedData';
import { 
  checkAndMigrateAllToFirestore, 
  forceMigrateAllToFirestore, 
  MigrationResult 
} from '../utils/firebaseSync';

export const SESSION_TIMEOUT_SECONDS = 15 * 60; // 15 Menit pembatasan sesi tidak aktif

interface AppContextType {
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  users: UserProfile[];
  desaList: Desa[];
  jenisPelayananList: JenisPelayanan[];
  records: PelayananRecord[];
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  
  // Cloud Sync Status & Migration
  cloudSyncStatus: CloudSyncStatus;
  isOnline: boolean;
  lastSyncTime: string | null;
  isMigrating: boolean;
  forceCloudSync: () => Promise<MigrationResult>;

  // Authentication & Session
  isAuthenticated: boolean;
  login: (username: string, password: string) => { success: boolean; message: string; user?: UserProfile };
  logout: (reason?: string) => void;
  logoutReason: string | null;
  clearLogoutReason: () => void;
  sessionSecondsLeft: number;
  extendSession: () => void;
  forgotPassword: (identifier: string) => { success: boolean; message: string; user?: UserProfile; tempPassword?: string };

  // Helpers
  generateNomorRegistrasi: (jenisPelayananId: string, tanggal: string) => string;
  getUserSeksi: (user?: UserProfile) => SeksiType | undefined;
  canAccessSeksi: (seksi: SeksiType) => boolean;
  isAdmin: boolean;

  // Actions
  addPelayananRecord: (record: Omit<PelayananRecord, 'id' | 'createdAt'>) => PelayananRecord;
  updatePelayananRecord: (id: string, record: Partial<PelayananRecord>) => void;
  deletePelayananRecord: (id: string) => void;

  addDesa: (desa: Omit<Desa, 'id'>) => void;
  updateDesa: (id: string, desa: Partial<Desa>) => void;
  deleteDesa: (id: string) => void;

  addJenisPelayanan: (jp: Omit<JenisPelayanan, 'id'>) => void;
  updateJenisPelayanan: (id: string, jp: Partial<JenisPelayanan>) => void;
  deleteJenisPelayanan: (id: string) => void;

  addUser: (user: Omit<UserProfile, 'id'>) => void;
  updateUser: (id: string, user: Partial<UserProfile>) => void;
  deleteUser: (id: string) => void;
  resetPassword: (userId: string, newPassword?: string) => string;
  switchUserById: (userId: string) => void;

  resetAllData: () => void;
  clearAllRecords: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'paten_sukatani_v4_clean_';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Clear any legacy demo caches on startup
  useEffect(() => {
    try {
      ['paten_sukatani_v1_records', 'paten_sukatani_v2_records', 'paten_sukatani_v3_records'].forEach(k => {
        localStorage.removeItem(k);
      });
    } catch {
      // ignore
    }
  }, []);

  // Initialize state with localStorage or default seed data
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}users`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].username) {
          return parsed;
        }
      } catch {
        // fallback
      }
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const savedId = localStorage.getItem(`${STORAGE_KEY_PREFIX}current_user_id`);
    if (savedId) {
      const found = users.find(u => u.id === savedId);
      if (found) return found;
    }
    return users[0] || INITIAL_USERS[0];
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const savedAuth = localStorage.getItem(`${STORAGE_KEY_PREFIX}is_authenticated`);
    return savedAuth === 'true';
  });

  const [logoutReason, setLogoutReason] = useState<string | null>(null);
  const [sessionSecondsLeft, setSessionSecondsLeft] = useState<number>(SESSION_TIMEOUT_SECONDS);
  const lastActivityRef = useRef<number>(Date.now());

  const [desaList, setDesaList] = useState<Desa[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}desa`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (
          Array.isArray(parsed) && 
          parsed.some(d => d.namaDesa === 'Sukamulya') && 
          parsed.some(d => d.namaDesa === 'Banjarsari')
        ) {
          return parsed;
        }
      } catch {
        // fallback
      }
    }
    return INITIAL_DESA;
  });

  const [jenisPelayananList, setJenisPelayananList] = useState<JenisPelayanan[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}jenis_pelayanan`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.some(j => j.id === 'jp-ynl-01')) {
          return parsed;
        }
      } catch {
        // fallback
      }
    }
    return INITIAL_JENIS_PELAYANAN;
  });

  const [records, setRecords] = useState<PelayananRecord[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}records`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      } catch {
        // fallback
      }
    }
    return INITIAL_PELAYANAN_RECORDS;
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [cloudSyncStatus, setCloudSyncStatus] = useState<CloudSyncStatus>('syncing');
  const [isOnline, setIsOnline] = useState<boolean>(() => typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    return localStorage.getItem(`${STORAGE_KEY_PREFIX}last_sync_time`) || null;
  });
  const [isMigrating, setIsMigrating] = useState<boolean>(false);

  // Monitor network online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setCloudSyncStatus('synced');
    };
    const handleOffline = () => {
      setIsOnline(false);
      setCloudSyncStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Test Firestore Connection on Boot & Trigger Automatic Migration of Local Storage
  useEffect(() => {
    let isMounted = true;

    async function initializeCloudSync() {
      setIsMigrating(true);
      setCloudSyncStatus('syncing');

      // Test connection
      await testFirestoreConnection();

      // Migrate localStorage data if Firestore is empty or missing documents
      try {
        const migResult = await checkAndMigrateAllToFirestore(
          users,
          records,
          desaList,
          jenisPelayananList
        );
        if (isMounted) {
          const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          setLastSyncTime(nowStr);
          localStorage.setItem(`${STORAGE_KEY_PREFIX}last_sync_time`, nowStr);
          setCloudSyncStatus(migResult.success ? 'synced' : 'error');
        }
      } catch (err) {
        console.warn('Inisialisasi sinkronisasi cloud:', err);
        if (isMounted) {
          setCloudSyncStatus(navigator.onLine ? 'error' : 'offline');
        }
      } finally {
        if (isMounted) {
          setIsMigrating(false);
        }
      }
    }

    initializeCloudSync();

    return () => {
      isMounted = false;
    };
  }, []); // Run once on app startup

  // Real-time synchronization with Firestore for users
  useEffect(() => {
    try {
      const usersCol = collection(db, 'users');
      const unsubscribe = onSnapshot(usersCol, (snapshot) => {
        if (!snapshot.empty) {
          const cloudUsers: UserProfile[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as UserProfile;
            if (data && data.id) {
              cloudUsers.push(data);
            }
          });
          if (cloudUsers.length > 0) {
            cloudUsers.sort((a, b) => a.level.localeCompare(b.level) || a.name.localeCompare(b.name));
            setUsers(cloudUsers);
            // If current user is present in cloudUsers, keep profile up to date
            setCurrentUser(prev => {
              const updated = cloudUsers.find(u => u.id === prev.id);
              return updated || prev;
            });
            setCloudSyncStatus('synced');
          }
        }
      }, (error) => {
        console.warn('Firestore users listener warning:', error);
      });

      return () => unsubscribe();
    } catch (e) {
      console.warn('Firestore users subscription error:', e);
    }
  }, []);

  // Real-time synchronization with Firestore for records
  useEffect(() => {
    try {
      const recordsCol = collection(db, 'records');
      const unsubscribe = onSnapshot(recordsCol, (snapshot) => {
        const cloudRecords: PelayananRecord[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as PelayananRecord;
          if (data && data.id) {
            cloudRecords.push(data);
          }
        });
        // Sort latest first
        cloudRecords.sort((a, b) => new Date(b.createdAt || b.tanggal).getTime() - new Date(a.createdAt || a.tanggal).getTime());
        setRecords(cloudRecords);
        setCloudSyncStatus('synced');
        const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setLastSyncTime(nowStr);
        localStorage.setItem(`${STORAGE_KEY_PREFIX}last_sync_time`, nowStr);
      }, (error) => {
        console.warn('Firestore records listener error (falling back to offline local storage):', error);
        setCloudSyncStatus(navigator.onLine ? 'error' : 'offline');
      });

      return () => unsubscribe();
    } catch (e) {
      console.warn('Firestore records subscription initialization error:', e);
    }
  }, []);

  // Real-time synchronization with Firestore for desa master data
  useEffect(() => {
    try {
      const desaCol = collection(db, 'desa');
      const unsubscribe = onSnapshot(desaCol, (snapshot) => {
        if (!snapshot.empty) {
          const cloudDesa: Desa[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as Desa;
            if (data && data.id) {
              cloudDesa.push(data);
            }
          });
          if (cloudDesa.length > 0) {
            cloudDesa.sort((a, b) => (a.kodeDesa || '').localeCompare(b.kodeDesa || ''));
            setDesaList(cloudDesa);
          }
        }
      }, (error) => {
        console.warn('Firestore desa listener error:', error);
      });

      return () => unsubscribe();
    } catch (e) {
      console.warn('Firestore desa subscription initialization error:', e);
    }
  }, []);

  // Real-time synchronization with Firestore for jenis_pelayanan master data
  useEffect(() => {
    try {
      const jpCol = collection(db, 'jenis_pelayanan');
      const unsubscribe = onSnapshot(jpCol, (snapshot) => {
        if (!snapshot.empty) {
          const cloudJp: JenisPelayanan[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as JenisPelayanan;
            if (data && data.id) {
              cloudJp.push(data);
            }
          });
          if (cloudJp.length > 0) {
            cloudJp.sort((a, b) => (a.kode || '').localeCompare(b.kode || ''));
            setJenisPelayananList(cloudJp);
          }
        }
      }, (error) => {
        console.warn('Firestore jenis_pelayanan listener error:', error);
      });

      return () => unsubscribe();
    } catch (e) {
      console.warn('Firestore jenis_pelayanan subscription initialization error:', e);
    }
  }, []);

  // Sync to localStorage as local instant offline cache
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}users`, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}desa`, JSON.stringify(desaList));
  }, [desaList]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}jenis_pelayanan`, JSON.stringify(jenisPelayananList));
  }, [jenisPelayananList]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}records`, JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}current_user_id`, currentUser.id);
  }, [currentUser]);

  // Manual Force Cloud Migration / Synchronization
  const forceCloudSync = async (): Promise<MigrationResult> => {
    setIsMigrating(true);
    setCloudSyncStatus('syncing');
    try {
      const res = await forceMigrateAllToFirestore(users, records, desaList, jenisPelayananList);
      const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastSyncTime(nowStr);
      localStorage.setItem(`${STORAGE_KEY_PREFIX}last_sync_time`, nowStr);
      setCloudSyncStatus(res.success ? 'synced' : 'error');
      return res;
    } catch (e) {
      const errRes: MigrationResult = {
        success: false,
        message: e instanceof Error ? e.message : 'Gagal sinkronisasi data.',
        counts: { users: users.length, records: records.length, desa: desaList.length, jenisPelayanan: jenisPelayananList.length },
        migratedAt: new Date().toISOString()
      };
      setCloudSyncStatus('error');
      return errRes;
    } finally {
      setIsMigrating(false);
    }
  };

  const isAdmin = currentUser.level === 'L1';

  const getUserSeksi = (user = currentUser): SeksiType | undefined => {
    if (user.level === 'L1') return undefined;
    if (user.seksi) return user.seksi;
    switch (user.level) {
      case 'L2': return 'Yanlik';
      case 'L3': return 'Pemerintahan';
      case 'L4': return 'Ekbang';
      case 'L5': return 'PMD';
      case 'L6': return 'Trantib';
      default: return undefined;
    }
  };

  const canAccessSeksi = (seksi: SeksiType): boolean => {
    if (isAdmin) return true;
    return getUserSeksi() === seksi;
  };

  // Generate automated registration code following the official format:
  // e.g. Format: "400.7.3.1/No/Bln/Thn" -> "400.7.3.1/045/IX/2026"
  const generateNomorRegistrasi = (jenisPelayananId: string, tanggal: string): string => {
    const jp = jenisPelayananList.find(j => j.id === jenisPelayananId);
    if (!jp) return '000/001/I/2026';

    const dateObj = new Date(tanggal || new Date());
    const month = dateObj.getMonth() + 1; // 1-12
    const year = dateObj.getFullYear();
    const romanMonth = toRomanNumeral(month);

    // Count existing records for this same service and month/year to determine next sequence number
    const matchingRecords = records.filter(r => {
      if (r.jenisPelayananId !== jenisPelayananId) return false;
      const recDate = new Date(r.tanggal);
      return recDate.getMonth() + 1 === month && recDate.getFullYear() === year;
    });

    // Inspect any existing sequence numbers in this month
    let maxSequence = 0;
    matchingRecords.forEach(r => {
      const parts = r.nomorRegistrasi.split('/');
      if (parts.length >= 2) {
        for (const p of parts) {
          const num = parseInt(p, 10);
          if (!isNaN(num) && num > 0 && num < 10000 && num > maxSequence) {
            maxSequence = num;
          }
        }
      }
    });

    const nextSeq = Math.max(maxSequence + 1, matchingRecords.length + 1, 1);
    const seqPadded = String(nextSeq).padStart(3, '0');
    const format = jp.formatKodeRegistrasi || `${jp.kode}/No/Bln/Thn`;
    
    // Replace standard format variables
    const generated = format
      .replace(/No/g, seqPadded)
      .replace(/NomorUrut/gi, seqPadded)
      .replace(/Bln/g, romanMonth)
      .replace(/Bulan/gi, romanMonth)
      .replace(/Thn/g, String(year))
      .replace(/Tahun/gi, String(year));

    return generated;
  };

  // --- Records Operations (Optimistic Local + Firestore) ---
  const addPelayananRecord = (data: Omit<PelayananRecord, 'id' | 'createdAt'>): PelayananRecord => {
    const newRecord: PelayananRecord = {
      ...data,
      id: `rec-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
    };

    // Optimistic local state update
    setRecords(prev => [newRecord, ...prev.filter(r => r.id !== newRecord.id)]);
    
    // Asynchronous Cloud Firestore persistence
    try {
      const sanitized = sanitizeForFirestore(newRecord);
      setDoc(doc(db, 'records', newRecord.id), sanitized)
        .then(() => {
          setCloudSyncStatus('synced');
          const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          setLastSyncTime(nowStr);
        })
        .catch(err => {
          console.warn('Firestore write record warning:', err);
        });
    } catch (err) {
      console.warn('Firestore setDoc error:', err);
    }

    return newRecord;
  };

  const updatePelayananRecord = (id: string, updatedData: Partial<PelayananRecord>) => {
    setRecords(prev => prev.map(rec => rec.id === id ? { ...rec, ...updatedData } : rec));
    try {
      const existing = records.find(r => r.id === id);
      if (existing) {
        const merged = { ...existing, ...updatedData };
        const sanitized = sanitizeForFirestore(merged);
        setDoc(doc(db, 'records', id), sanitized, { merge: true })
          .then(() => {
            setCloudSyncStatus('synced');
            const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            setLastSyncTime(nowStr);
          })
          .catch(err => {
            console.warn('Firestore update record warning:', err);
          });
      }
    } catch (err) {
      console.warn('Firestore updateDoc error:', err);
    }
  };

  const deletePelayananRecord = (id: string) => {
    setRecords(prev => prev.filter(rec => rec.id !== id));
    try {
      deleteDoc(doc(db, 'records', id))
        .then(() => {
          setCloudSyncStatus('synced');
          const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          setLastSyncTime(nowStr);
        })
        .catch(err => {
          console.warn('Firestore delete record warning:', err);
        });
    } catch (err) {
      console.warn('Firestore deleteDoc error:', err);
    }
  };

  // --- Master Data Desa Operations ---
  const addDesa = (data: Omit<Desa, 'id'>) => {
    const newDesa: Desa = {
      ...data,
      id: `desa-${Date.now()}`,
    };
    setDesaList(prev => [...prev, newDesa]);
    try {
      const sanitized = sanitizeForFirestore(newDesa);
      setDoc(doc(db, 'desa', newDesa.id), sanitized).catch(err => {
        console.warn('Firestore write desa warning:', err);
      });
    } catch (err) {
      console.warn('Firestore setDoc desa error:', err);
    }
  };

  const updateDesa = (id: string, updatedData: Partial<Desa>) => {
    setDesaList(prev => prev.map(d => d.id === id ? { ...d, ...updatedData } : d));
    try {
      const existing = desaList.find(d => d.id === id);
      if (existing) {
        const sanitized = sanitizeForFirestore({ ...existing, ...updatedData });
        setDoc(doc(db, 'desa', id), sanitized, { merge: true }).catch(err => {
          console.warn('Firestore update desa warning:', err);
        });
      }
    } catch (err) {
      console.warn('Firestore update desa error:', err);
    }
  };

  const deleteDesa = (id: string) => {
    setDesaList(prev => prev.filter(d => d.id !== id));
    try {
      deleteDoc(doc(db, 'desa', id)).catch(err => {
        console.warn('Firestore delete desa warning:', err);
      });
    } catch (err) {
      console.warn('Firestore delete desa error:', err);
    }
  };

  // --- Master Data Jenis Pelayanan Operations ---
  const addJenisPelayanan = (data: Omit<JenisPelayanan, 'id'>) => {
    const newJp: JenisPelayanan = {
      ...data,
      id: `jp-${Date.now()}`,
    };
    setJenisPelayananList(prev => [...prev, newJp]);
    try {
      const sanitized = sanitizeForFirestore(newJp);
      setDoc(doc(db, 'jenis_pelayanan', newJp.id), sanitized).catch(err => {
        console.warn('Firestore write jenis_pelayanan warning:', err);
      });
    } catch (err) {
      console.warn('Firestore setDoc jenis_pelayanan error:', err);
    }
  };

  const updateJenisPelayanan = (id: string, updatedData: Partial<JenisPelayanan>) => {
    setJenisPelayananList(prev => prev.map(jp => jp.id === id ? { ...jp, ...updatedData } : jp));
    try {
      const existing = jenisPelayananList.find(j => j.id === id);
      if (existing) {
        const sanitized = sanitizeForFirestore({ ...existing, ...updatedData });
        setDoc(doc(db, 'jenis_pelayanan', id), sanitized, { merge: true }).catch(err => {
          console.warn('Firestore update jenis_pelayanan warning:', err);
        });
      }
    } catch (err) {
      console.warn('Firestore update jenis_pelayanan error:', err);
    }
  };

  const deleteJenisPelayanan = (id: string) => {
    setJenisPelayananList(prev => prev.filter(jp => jp.id !== id));
    try {
      deleteDoc(doc(db, 'jenis_pelayanan', id)).catch(err => {
        console.warn('Firestore delete jenis_pelayanan error:', err);
      });
    } catch (err) {
      console.warn('Firestore delete jenis_pelayanan error:', err);
    }
  };

  // --- User Operations (Optimistic Local + Firestore) ---
  const addUser = (data: Omit<UserProfile, 'id'>) => {
    const newUser: UserProfile = {
      ...data,
      id: `user-${Date.now()}`,
    };
    setUsers(prev => [...prev, newUser]);
    try {
      const sanitized = sanitizeForFirestore(newUser);
      setDoc(doc(db, 'users', newUser.id), sanitized).catch(err => {
        console.warn('Firestore write user warning:', err);
      });
    } catch (err) {
      console.warn('Firestore setDoc user error:', err);
    }
  };

  const updateUser = (id: string, updatedData: Partial<UserProfile>) => {
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        const updated = { ...u, ...updatedData };
        if (currentUser.id === id) {
          setCurrentUser(updated);
        }
        return updated;
      }
      return u;
    }));
    try {
      const existing = users.find(u => u.id === id);
      if (existing) {
        const sanitized = sanitizeForFirestore({ ...existing, ...updatedData });
        setDoc(doc(db, 'users', id), sanitized, { merge: true }).catch(err => {
          console.warn('Firestore update user warning:', err);
        });
      }
    } catch (err) {
      console.warn('Firestore update user error:', err);
    }
  };

  const deleteUser = (id: string) => {
    if (users.length <= 1) return;
    setUsers(prev => prev.filter(u => u.id !== id));
    if (currentUser.id === id) {
      const remaining = users.filter(u => u.id !== id);
      if (remaining.length > 0) setCurrentUser(remaining[0]);
    }
    try {
      deleteDoc(doc(db, 'users', id)).catch(err => {
        console.warn('Firestore delete user warning:', err);
      });
    } catch (err) {
      console.warn('Firestore delete user error:', err);
    }
  };

  const resetPassword = (userId: string, newPassword?: string): string => {
    const user = users.find(u => u.id === userId);
    const generatedPass = newPassword || `${user?.username || 'User'}123`;
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        return { ...u, password: generatedPass };
      }
      return u;
    }));
    try {
      setDoc(doc(db, 'users', userId), { password: generatedPass }, { merge: true }).catch(err => {
        console.warn('Firestore resetPassword warning:', err);
      });
    } catch (err) {
      console.warn('Firestore resetPassword error:', err);
    }
    return generatedPass;
  };

  const switchUserById = (userId: string) => {
    const found = users.find(u => u.id === userId);
    if (found) {
      setCurrentUser(found);
      // If user is restricted from current tab (e.g. Master Data / Kelola User for non-admin), switch to dashboard
      if (found.level !== 'L1' && (activeTab === 'master-data' || activeTab === 'kelola-user')) {
        setActiveTab('dashboard');
      }
    }
  };

  const extendSession = useCallback(() => {
    lastActivityRef.current = Date.now();
    setSessionSecondsLeft(SESSION_TIMEOUT_SECONDS);
  }, []);

  const clearLogoutReason = useCallback(() => {
    setLogoutReason(null);
  }, []);

  const logout = useCallback((reason?: string) => {
    setIsAuthenticated(false);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}is_authenticated`);
    if (reason) {
      setLogoutReason(reason);
    }
  }, []);

  const login = useCallback((username: string, password: string) => {
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    const found = users.find(u => 
      (u.username && u.username.toLowerCase() === cleanUser) ||
      (u.email && u.email.toLowerCase() === cleanUser)
    );

    if (!found || found.password !== cleanPass) {
      return {
        success: false,
        message: 'Username atau Password tidak sesuai',
      };
    }

    if (found.status === 'Nonaktif') {
      return {
        success: false,
        message: 'Akun Anda saat ini berstatus Nonaktif. Silakan hubungi Administrator Level 1.',
      };
    }

    // Success
    setCurrentUser(found);
    setIsAuthenticated(true);
    setLogoutReason(null);
    lastActivityRef.current = Date.now();
    setSessionSecondsLeft(SESSION_TIMEOUT_SECONDS);
    localStorage.setItem(`${STORAGE_KEY_PREFIX}is_authenticated`, 'true');
    localStorage.setItem(`${STORAGE_KEY_PREFIX}current_user_id`, found.id);
    setActiveTab('dashboard');

    return {
      success: true,
      message: 'Login Berhasil',
      user: found,
    };
  }, [users]);

  const forgotPassword = useCallback((identifier: string) => {
    const clean = identifier.trim().toLowerCase();
    const found = users.find(u => 
      (u.username && u.username.toLowerCase() === clean) ||
      (u.email && u.email.toLowerCase() === clean)
    );

    if (!found) {
      return {
        success: false,
        message: 'Akun pengguna atau email tidak terdaftar dalam sistem.',
      };
    }

    // Reset password to standard format (Username123)
    const newPass = `${found.username || 'User'}123`;
    setUsers(prev => prev.map(u => u.id === found.id ? { ...u, password: newPass } : u));
    
    // Sync new password to Firestore
    try {
      setDoc(doc(db, 'users', found.id), { password: newPass }, { merge: true }).catch(e => {
        console.warn('Firestore forgotPassword update warning:', e);
      });
    } catch (e) {
      console.warn('Firestore forgotPassword update error:', e);
    }

    return {
      success: true,
      message: `Password akun ${found.name} (${found.username}) berhasil direset ke sandi standar: ${newPass}`,
      user: found,
      tempPassword: newPass,
    };
  }, [users]);

  // Session timeout inactivity listener
  useEffect(() => {
    if (!isAuthenticated) return;

    const handleActivity = () => {
      lastActivityRef.current = Date.now();
    };

    const events = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
    events.forEach(e => window.addEventListener(e, handleActivity, { passive: true }));

    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - lastActivityRef.current) / 1000);
      const remaining = Math.max(0, SESSION_TIMEOUT_SECONDS - elapsed);
      setSessionSecondsLeft(remaining);

      if (remaining <= 0) {
        clearInterval(timer);
        logout('Sesi Anda telah berakhir karena tidak ada aktivitas selama 15 menit (Session Timeout). Silakan login kembali.');
      }
    }, 1000);

    return () => {
      events.forEach(e => window.removeEventListener(e, handleActivity));
      clearInterval(timer);
    };
  }, [isAuthenticated, logout]);

  const clearAllRecords = () => {
    setRecords([]);
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}records`, JSON.stringify([]));
    } catch {
      // ignore
    }
    // Delete documents in Firestore records collection
    try {
      records.forEach(r => {
        deleteDoc(doc(db, 'records', r.id)).catch(() => {});
      });
    } catch (e) {
      console.warn('Firestore clear records warning:', e);
    }
  };

  const resetAllData = () => {
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setDesaList(INITIAL_DESA);
    setJenisPelayananList(INITIAL_JENIS_PELAYANAN);
    setRecords(INITIAL_PELAYANAN_RECORDS);
    setActiveTab('dashboard');
    setIsAuthenticated(false);
    setLogoutReason(null);
    localStorage.clear();
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        users,
        desaList,
        jenisPelayananList,
        records,
        activeTab,
        setActiveTab,
        cloudSyncStatus,
        isOnline,
        lastSyncTime,
        isMigrating,
        forceCloudSync,
        isAuthenticated,
        login,
        logout,
        logoutReason,
        clearLogoutReason,
        sessionSecondsLeft,
        extendSession,
        forgotPassword,
        generateNomorRegistrasi,
        getUserSeksi,
        canAccessSeksi,
        isAdmin,
        addPelayananRecord,
        updatePelayananRecord,
        deletePelayananRecord,
        addDesa,
        updateDesa,
        deleteDesa,
        addJenisPelayanan,
        updateJenisPelayanan,
        deleteJenisPelayanan,
        addUser,
        updateUser,
        deleteUser,
        resetPassword,
        switchUserById,
        resetAllData,
        clearAllRecords,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
