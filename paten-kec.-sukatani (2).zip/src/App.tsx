import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginView } from './components/LoginView';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { InputPelayananView } from './components/InputPelayananView';
import { LaporanGrafikView } from './components/LaporanGrafikView';
import { MasterDataView } from './components/MasterDataView';
import { KelolaUserView } from './components/KelolaUserView';

const MainAppContent: React.FC = () => {
  const { isAuthenticated, activeTab } = useApp();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // If not logged in, show formal Government Login view
  if (!isAuthenticated) {
    return <LoginView />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800 antialiased selection:bg-emerald-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar onToggleSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)} />

      {/* Main Body Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          isOpen={mobileSidebarOpen}
          onClose={() => setMobileSidebarOpen(false)}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-6">
            {activeTab === 'dashboard' && <DashboardView />}
            {activeTab === 'input-pelayanan' && <InputPelayananView />}
            {activeTab === 'laporan-grafik' && <LaporanGrafikView />}
            {activeTab === 'master-data' && <MasterDataView />}
            {activeTab === 'kelola-user' && <KelolaUserView />}
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-3 px-4 sm:px-8 text-center sm:flex sm:justify-between sm:items-center text-xs text-slate-500 shrink-0">
        <div className="flex items-center justify-center sm:justify-start gap-2">
          <span className="font-semibold text-slate-700">Pemerintah Kabupaten Bekasi</span>
          <span>•</span>
          <span>Kecamatan Sukatani</span>
        </div>
        <p className="mt-1 sm:mt-0 text-[11px] text-slate-400">
          PATEN (Pelayanan Administrasi Terpadu Kecamatan) &copy; {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
