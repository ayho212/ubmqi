export type UserLevel = 
  | 'L1' // Administrator
  | 'L2' // Seksi Yanlik
  | 'L3' // Seksi Pemerintahan
  | 'L4' // Seksi Ekbang
  | 'L5' // Seksi PMD
  | 'L6'; // Seksi Trantib

export type SeksiType = 
  | 'Yanlik'
  | 'Pemerintahan'
  | 'Ekbang'
  | 'PMD'
  | 'Trantib';

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  password?: string;
  level: UserLevel;
  seksi?: SeksiType;
  status: 'Aktif' | 'Nonaktif';
}

export type User = UserProfile;

export interface Desa {
  id: string;
  kodeDesa: string;
  namaDesa: string;
}

export interface JenisPelayanan {
  id: string;
  kode: string;
  namaPelayanan: string;
  seksi: SeksiType;
  formatKodeRegistrasi?: string; // e.g. "400.7.3.1/No/Bln/Thn"
  persyaratan?: string[];
}

export interface PelayananRecord {
  id: string;
  nomorRegistrasi: string;
  jenisPelayananId: string;
  namaPelayanan: string;
  tanggal: string; // YYYY-MM-DD
  perihal: string; // Perihal / Keperluan permohonan
  namaPemohon: string;
  nik: string; // Nomor Induk Kependudukan (16 digit)
  desaId: string;
  namaDesa: string;
  alamat: string; // Kp/RT/RW
  keterangan: string;
  petugas: string;
  seksi: SeksiType;
  linkGoogleDrive?: string; // Upload dokumen (link google drive)
  createdAt: string; // ISO string
}

export type CloudSyncStatus = 'synced' | 'syncing' | 'offline' | 'error';

export type ActiveTab = 
  | 'dashboard'
  | 'input-pelayanan'
  | 'laporan-grafik'
  | 'master-data'
  | 'kelola-user';
