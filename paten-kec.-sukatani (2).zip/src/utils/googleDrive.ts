/**
 * Google Drive Integration Utility
 * Using Firebase Auth (GoogleAuthProvider with Drive scopes) & Google Drive v3 REST API
 * Following Google Workspace Integration Skill guidelines
 */
import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User 
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export interface DriveUser {
  displayName: string;
  emailAddress: string;
  photoLink?: string;
  storageQuota?: {
    limit?: string;
    usage?: string;
    usageInDrive?: string;
  };
}

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
  webViewLink?: string;
  iconLink?: string;
  thumbnailLink?: string;
}

export const SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.activity',
  'https://www.googleapis.com/auth/drive.activity.readonly',
  'https://www.googleapis.com/auth/drive.appdata',
  'https://www.googleapis.com/auth/drive.apps.readonly',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.install',
  'https://www.googleapis.com/auth/drive.meet.readonly',
  'https://www.googleapis.com/auth/drive.metadata',
  'https://www.googleapis.com/auth/drive.metadata.readonly',
  'https://www.googleapis.com/auth/drive.photos.readonly',
  'https://www.googleapis.com/auth/drive.readonly',
  'https://www.googleapis.com/auth/drive.scripts',
];

const FOLDER_NAME = 'PATEN Kec. Sukatani - Arsip & Register';

// Initialize Firebase app if not already initialized
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => {
  provider.addScope(scope);
});
provider.setCustomParameters({
  prompt: 'consent select_account',
});

// Cache the access token strictly in memory (do NOT store in localStorage or sessionStorage)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

/**
 * Initialize Auth State Listener
 * Call this on app load or view load.
 */
export const initDriveAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // Token not in memory after refresh; user can click Sign in with Google to re-acquire token
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Trigger Google Sign In popup to obtain Google Drive OAuth access token
 */
export const googleSignInDrive = async (): Promise<{ user: User; accessToken: string }> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Gagal memperoleh token akses Google Drive dari Firebase Auth.');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign in Google Drive error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Get current in-memory cached access token
 */
export const getDriveAccessToken = (): string | null => {
  return cachedAccessToken;
};

/**
 * Compatibility wrapper for getting current in-memory token
 */
export function getStoredDriveToken(): string | null {
  return getDriveAccessToken();
}

/**
 * Compatibility wrapper for requesting token via Firebase Auth popup
 */
export async function requestGoogleDriveToken(
  onSuccess: (token: string) => void,
  onError: (error: any) => void
): Promise<void> {
  try {
    const res = await googleSignInDrive();
    if (res?.accessToken) {
      onSuccess(res.accessToken);
    } else {
      onError(new Error('Token akses tidak ditemukan'));
    }
  } catch (err) {
    onError(err);
  }
}

/**
 * Sign out and clear in-memory token cache
 */
export const googleSignOutDrive = async (): Promise<void> => {
  await signOut(auth);
  cachedAccessToken = null;
};

/**
 * Fetch Google User Info & Drive Storage Quota from Google Drive API
 */
export async function fetchDriveUserInfo(token: string): Promise<DriveUser> {
  const res = await fetch(
    'https://www.googleapis.com/drive/v3/about?fields=user,storageQuota',
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(`Gagal mengambil data akun Google Drive (${res.status}): ${errText}`);
  }
  const data = await res.json();
  return {
    displayName: data.user?.displayName || 'Pengguna Google',
    emailAddress: data.user?.emailAddress || '',
    photoLink: data.user?.photoLink,
    storageQuota: data.storageQuota,
  };
}

/**
 * Find or create dedicated folder in Google Drive
 */
export async function getOrCreateAppFolder(token: string, folderName = FOLDER_NAME): Promise<string> {
  // Search for existing folder
  const query = encodeURIComponent(
    `name = '${folderName}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`
  );
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id, name)`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (searchRes.ok) {
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      return searchData.files[0].id;
    }
  }

  // Create folder if not found
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
      description: 'Folder arsip dokumen dan buku register PATEN Kecamatan Sukatani',
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text().catch(() => '');
    throw new Error(`Gagal membuat folder di Google Drive (${createRes.status}): ${errText}`);
  }

  const createData = await createRes.json();
  return createData.id;
}

/**
 * Upload a file to Google Drive using multipart upload
 */
export async function uploadFileToDrive(
  token: string,
  params: {
    name: string;
    mimeType: string;
    content: Blob | string;
    folderId?: string;
  }
): Promise<DriveFileItem> {
  let targetFolderId = params.folderId;
  if (!targetFolderId) {
    targetFolderId = await getOrCreateAppFolder(token);
  }

  const metadata = {
    name: params.name,
    mimeType: params.mimeType,
    parents: [targetFolderId],
  };

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const blobContent =
    typeof params.content === 'string'
      ? new Blob([params.content], { type: params.mimeType })
      : params.content;

  const metadataBlob = new Blob(
    [
      delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        `Content-Type: ${params.mimeType}\r\n\r\n`,
    ],
    { type: 'text/plain' }
  );

  const endBlob = new Blob([closeDelimiter], { type: 'text/plain' });

  const multipartBody = new Blob([metadataBlob, blobContent, endBlob], {
    type: `multipart/related; boundary=${boundary}`,
  });

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,createdTime,webViewLink,iconLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: multipartBody,
    }
  );

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Gagal mengunggah berkas ke Google Drive (${res.status}): ${errBody}`);
  }

  return await res.json();
}

/**
 * List files in the PATEN folder
 */
export async function listFilesInAppFolder(
  token: string,
  folderId?: string
): Promise<DriveFileItem[]> {
  let targetFolderId = folderId;
  if (!targetFolderId) {
    targetFolderId = await getOrCreateAppFolder(token);
  }

  const query = encodeURIComponent(`'${targetFolderId}' in parents and trashed = false`);
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,mimeType,size,createdTime,modifiedTime,webViewLink,iconLink,thumbnailLink)&orderBy=createdTime desc&pageSize=100`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(`Gagal mengambil daftar berkas dari Google Drive (${res.status}): ${errText}`);
  }

  const data = await res.json();
  return data.files || [];
}

/**
 * Delete file from Google Drive
 * Must be preceded by explicit user confirmation in UI
 */
export async function deleteDriveFile(token: string, fileId: string): Promise<void> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!res.ok && res.status !== 404) {
    const errText = await res.text().catch(() => '');
    throw new Error(`Gagal menghapus berkas dari Google Drive (${res.status}): ${errText}`);
  }
}

/**
 * Format bytes to readable string (KB, MB, GB)
 */
export function formatBytes(bytes?: string | number): string {
  if (!bytes) return '0 B';
  const num = typeof bytes === 'string' ? parseInt(bytes, 10) : bytes;
  if (isNaN(num) || num === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(num) / Math.log(k));
  return `${parseFloat((num / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}
