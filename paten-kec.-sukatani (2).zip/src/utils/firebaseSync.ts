import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  writeBatch
} from 'firebase/firestore';
import { db, sanitizeForFirestore } from '../lib/firebase';
import { UserProfile, Desa, JenisPelayanan, PelayananRecord } from '../types';
import { 
  INITIAL_USERS, 
  INITIAL_DESA, 
  INITIAL_JENIS_PELAYANAN, 
  INITIAL_PELAYANAN_RECORDS 
} from '../data/seedData';

export interface MigrationResult {
  success: boolean;
  message: string;
  counts: {
    users: number;
    records: number;
    desa: number;
    jenisPelayanan: number;
  };
  migratedAt: string;
}

/**
 * Otomatis mengecek dan memigrasikan data lokal ke Cloud Firestore
 * Jika koleksi di Firestore belum berisi data, data dari localStorage / seed data
 * akan diunggah ke basis data terpusat.
 */
export async function checkAndMigrateAllToFirestore(
  localUsers: UserProfile[],
  localRecords: PelayananRecord[],
  localDesa: Desa[],
  localJenisPelayanan: JenisPelayanan[]
): Promise<MigrationResult> {
  const result: MigrationResult = {
    success: true,
    message: '',
    counts: { users: 0, records: 0, desa: 0, jenisPelayanan: 0 },
    migratedAt: new Date().toISOString(),
  };

  try {
    // 1. Migrasi Data Pengguna (Users)
    try {
      const usersSnap = await getDocs(collection(db, 'users'));
      if (usersSnap.empty) {
        const usersToPush = localUsers.length > 0 ? localUsers : INITIAL_USERS;
        const batch = writeBatch(db);
        usersToPush.forEach(user => {
          const userRef = doc(db, 'users', user.id);
          batch.set(userRef, sanitizeForFirestore(user), { merge: true });
        });
        await batch.commit();
        result.counts.users = usersToPush.length;
      } else {
        result.counts.users = usersSnap.size;
      }
    } catch (err) {
      console.warn('Gagal migrasi users ke Firestore:', err);
    }

    // 2. Migrasi Master Data Desa
    try {
      const desaSnap = await getDocs(collection(db, 'desa'));
      if (desaSnap.empty) {
        const desaToPush = localDesa.length > 0 ? localDesa : INITIAL_DESA;
        const batch = writeBatch(db);
        desaToPush.forEach(desa => {
          const dRef = doc(db, 'desa', desa.id);
          batch.set(dRef, sanitizeForFirestore(desa), { merge: true });
        });
        await batch.commit();
        result.counts.desa = desaToPush.length;
      } else {
        result.counts.desa = desaSnap.size;
      }
    } catch (err) {
      console.warn('Gagal migrasi desa ke Firestore:', err);
    }

    // 3. Migrasi Master Data Jenis Pelayanan
    try {
      const jpSnap = await getDocs(collection(db, 'jenis_pelayanan'));
      if (jpSnap.empty) {
        const jpToPush = localJenisPelayanan.length > 0 ? localJenisPelayanan : INITIAL_JENIS_PELAYANAN;
        const batch = writeBatch(db);
        jpToPush.forEach(jp => {
          const jpRef = doc(db, 'jenis_pelayanan', jp.id);
          batch.set(jpRef, sanitizeForFirestore(jp), { merge: true });
        });
        await batch.commit();
        result.counts.jenisPelayanan = jpToPush.length;
      } else {
        result.counts.jenisPelayanan = jpSnap.size;
      }
    } catch (err) {
      console.warn('Gagal migrasi jenis_pelayanan ke Firestore:', err);
    }

    // 4. Migrasi Catatan Pelayanan (Records)
    try {
      const recordsSnap = await getDocs(collection(db, 'records'));
      if (recordsSnap.empty) {
        const recordsToPush = localRecords.length > 0 ? localRecords : INITIAL_PELAYANAN_RECORDS;
        if (recordsToPush.length > 0) {
          const batch = writeBatch(db);
          recordsToPush.forEach(rec => {
            const recRef = doc(db, 'records', rec.id);
            batch.set(recRef, sanitizeForFirestore(rec), { merge: true });
          });
          await batch.commit();
        }
        result.counts.records = recordsToPush.length;
      } else {
        // Cek jika ada catatan lokal yang belum tersimpan di Firestore
        const existingCloudIds = new Set<string>();
        recordsSnap.forEach(d => existingCloudIds.add(d.id));

        const unsynced = localRecords.filter(r => !existingCloudIds.has(r.id));
        if (unsynced.length > 0) {
          const batch = writeBatch(db);
          unsynced.forEach(rec => {
            const recRef = doc(db, 'records', rec.id);
            batch.set(recRef, sanitizeForFirestore(rec), { merge: true });
          });
          await batch.commit();
        }
        result.counts.records = recordsSnap.size + unsynced.length;
      }
    } catch (err) {
      console.warn('Gagal migrasi records ke Firestore:', err);
    }

    // Simpan metadata status migrasi
    try {
      await setDoc(doc(db, 'metadata', 'migration_status'), {
        lastSync: new Date().toISOString(),
        totalUsers: result.counts.users,
        totalRecords: result.counts.records,
        totalDesa: result.counts.desa,
        totalJenisPelayanan: result.counts.jenisPelayanan,
        source: 'PATEN Sukatani Web Client',
      }, { merge: true });
    } catch {
      // ignore metadata write error
    }

    result.message = 'Semua data pengguna, master data, dan catatan register berhasil tersinkronisasi ke Cloud Database Firestore!';
    return result;
  } catch (error) {
    result.success = false;
    result.message = error instanceof Error ? error.message : 'Terjadi kendala saat migrasi data.';
    return result;
  }
}

/**
 * Fungsi migrasi paksa (manual push) seluruh data lokal yang aktif ke Cloud Firestore
 */
export async function forceMigrateAllToFirestore(
  users: UserProfile[],
  records: PelayananRecord[],
  desaList: Desa[],
  jenisPelayananList: JenisPelayanan[]
): Promise<MigrationResult> {
  const result: MigrationResult = {
    success: true,
    message: '',
    counts: {
      users: users.length,
      records: records.length,
      desa: desaList.length,
      jenisPelayanan: jenisPelayananList.length,
    },
    migratedAt: new Date().toISOString(),
  };

  try {
    // 1. Simpan Users
    const usersBatch = writeBatch(db);
    users.forEach(u => {
      usersBatch.set(doc(db, 'users', u.id), sanitizeForFirestore(u), { merge: true });
    });
    await usersBatch.commit();

    // 2. Simpan Desa
    const desaBatch = writeBatch(db);
    desaList.forEach(d => {
      desaBatch.set(doc(db, 'desa', d.id), sanitizeForFirestore(d), { merge: true });
    });
    await desaBatch.commit();

    // 3. Simpan Jenis Pelayanan
    const jpBatch = writeBatch(db);
    jenisPelayananList.forEach(jp => {
      jpBatch.set(doc(db, 'jenis_pelayanan', jp.id), sanitizeForFirestore(jp), { merge: true });
    });
    await jpBatch.commit();

    // 4. Simpan Catatan Pelayanan
    if (records.length > 0) {
      const recBatch = writeBatch(db);
      records.forEach(r => {
        recBatch.set(doc(db, 'records', r.id), sanitizeForFirestore(r), { merge: true });
      });
      await recBatch.commit();
    }

    // 5. Update Metadata
    await setDoc(doc(db, 'metadata', 'migration_status'), {
      lastManualSync: new Date().toISOString(),
      counts: result.counts,
      syncBy: 'Administrator PATEN Sukatani',
    }, { merge: true });

    result.message = `Berhasil mengunggah ${records.length} berkas register, ${users.length} akun petugas, dan seluruh master data ke Cloud Firestore terpusat!`;
    return result;
  } catch (error) {
    result.success = false;
    result.message = error instanceof Error ? error.message : 'Gagal melakukan sinkronisasi paksa ke Firestore.';
    return result;
  }
}
