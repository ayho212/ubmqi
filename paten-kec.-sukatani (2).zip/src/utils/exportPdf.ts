import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { JenisPelayanan, SeksiType, PelayananRecord } from '../types';

export interface GroupedStatItem {
  service: JenisPelayanan;
  count: number;
}

export interface GroupedSeksiStat {
  seksi: SeksiType;
  items: GroupedStatItem[];
  subtotal: number;
}

interface GenerateRekapPdfParams {
  monthName: string;
  year: number;
  groupedStats: GroupedSeksiStat[];
  totalCount: number;
}

export function downloadRekapitulasiPDF({
  monthName,
  year,
  groupedStats,
  totalCount,
}: GenerateRekapPdfParams): void {
  // Create A4 portrait PDF document
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // --- 1. KOP SURAT (HEADER RESMI) ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 16, { align: 'center' });
  doc.setFontSize(14);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 22, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(
    'Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630',
    pageWidth / 2,
    27,
    { align: 'center' }
  );
  doc.text('Laman Resmi: kecamatansukatani.bekasikab.go.id | Email: kecamatan.sukatani@bekasikab.go.id', pageWidth / 2, 31, { align: 'center' });

  // Double horizontal rule
  doc.setLineWidth(0.8);
  doc.line(14, 34, pageWidth - 14, 34);
  doc.setLineWidth(0.2);
  doc.line(14, 35.2, pageWidth - 14, 35.2);

  // --- 2. JUDUL LAPORAN ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('REKAPITULASI PELAYANAN ADMINISTRASI TERPADU KECAMATAN (PATEN)', pageWidth / 2, 42, {
    align: 'center',
  });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text(`Periode: ${monthName} ${year}`, pageWidth / 2, 47, { align: 'center' });

  // --- 3. DATA TABLE BODY ---
  const tableRows: (string | number)[][] = [];

  groupedStats.forEach((group) => {
    // Seksi header row
    tableRows.push([
      `▶ Seksi ${group.seksi}`,
      '',
      '',
      '',
      group.subtotal,
    ]);

    group.items.forEach((item, idx) => {
      tableRows.push([
        idx + 1,
        item.service.kode,
        item.service.namaPelayanan,
        group.seksi,
        item.count,
      ]);
    });
  });

  // Grand Total row
  tableRows.push([
    'TOTAL KESELURUHAN PELAYANAN',
    '',
    '',
    '',
    totalCount,
  ]);

  autoTable(doc, {
    startY: 52,
    head: [['No', 'Kode', 'Jenis Pelayanan Administrasi', 'Seksi', 'Jumlah']],
    body: tableRows,
    theme: 'grid',
    styles: {
      font: 'helvetica',
      fontSize: 8,
      cellPadding: 2,
      lineColor: [180, 180, 180],
      lineWidth: 0.15,
      textColor: [30, 30, 30],
    },
    headStyles: {
      fillColor: [240, 243, 246],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      halign: 'center',
      lineColor: [150, 150, 150],
      lineWidth: 0.2,
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 12 },
      1: { halign: 'center', cellWidth: 22, fontStyle: 'bold' },
      2: { halign: 'left', cellWidth: 'auto' },
      3: { halign: 'center', cellWidth: 26 },
      4: { halign: 'right', cellWidth: 20, fontStyle: 'bold' },
    },
    didParseCell: (data) => {
      const rowIndex = data.row.index;
      const rowData = tableRows[rowIndex];

      // Check if it's a Section Header Row
      if (typeof rowData[0] === 'string' && rowData[0].startsWith('▶ Seksi')) {
        if (data.column.index === 0) {
          data.cell.colSpan = 4;
          data.cell.styles.halign = 'left';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [241, 245, 249];
        } else if (data.column.index === 4) {
          data.cell.styles.halign = 'right';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [241, 245, 249];
        }
      }

      // Check if it's the Total Keseluruhan Row
      if (typeof rowData[0] === 'string' && rowData[0].startsWith('TOTAL KESELURUHAN')) {
        if (data.column.index === 0) {
          data.cell.colSpan = 4;
          data.cell.styles.halign = 'left';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [226, 232, 240];
        } else if (data.column.index === 4) {
          data.cell.styles.halign = 'right';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [226, 232, 240];
        }
      }
    },
  });

  // --- 4. TANDA TANGAN (SIGNATURE BLOCK) ---
  // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
  const finalY = (doc.lastAutoTable?.finalY || 160) + 10;
  let signatureY = finalY;
  if (signatureY > 230) {
    doc.addPage();
    signatureY = 25;
  }

  const signX = pageWidth - 75;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Sukatani, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, signX + 30, signatureY, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Camat Sukatani,', signX + 30, signatureY + 5, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Drs. H. AGUS DAHLAN, MM', signX + 30, signatureY + 28, { align: 'center' });
  doc.line(signX + 5, signatureY + 29, signX + 55, signatureY + 29);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('NIP. 197408171993111001', signX + 30, signatureY + 34, { align: 'center' });

  // Save / trigger download
  const cleanMonth = monthName.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Laporan_Rekapitulasi_Pelayanan_Sukatani_${cleanMonth}_${year}.pdf`;
  doc.save(filename);
}

export function generateRekapitulasiPDFBlob(params: GenerateRekapPdfParams): { blob: Blob; filename: string } {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 16, { align: 'center' });
  doc.setFontSize(14);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 22, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text('Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630', pageWidth / 2, 27, { align: 'center' });
  doc.text('Laman Resmi: kecamatansukatani.bekasikab.go.id | Email: kecamatan.sukatani@bekasikab.go.id', pageWidth / 2, 31, { align: 'center' });

  doc.setLineWidth(0.8);
  doc.line(14, 34, pageWidth - 14, 34);
  doc.setLineWidth(0.2);
  doc.line(14, 35.2, pageWidth - 14, 35.2);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('REKAPITULASI PELAYANAN ADMINISTRASI TERPADU KECAMATAN (PATEN)', pageWidth / 2, 42, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text(`Periode: Bulan ${params.monthName} ${params.year}`, pageWidth / 2, 48, { align: 'center' });

  const tableRows: (string | number)[][] = [];
  let rowNumber = 1;

  params.groupedStats.forEach((group) => {
    tableRows.push([`▶ Seksi ${group.seksi}`, '', '', '', '']);
    group.items.forEach((item) => {
      tableRows.push([
        rowNumber++,
        item.service.kode,
        item.service.namaPelayanan,
        'Berkas',
        item.count,
      ]);
    });
    tableRows.push([`Subtotal Seksi ${group.seksi}`, '', '', '', group.subtotal]);
  });

  tableRows.push(['TOTAL KESELURUHAN PELAYANAN', '', '', '', params.totalCount]);

  autoTable(doc, {
    startY: 53,
    head: [['No', 'Kode', 'Jenis Pelayanan', 'Satuan', 'Jumlah']],
    body: tableRows,
    theme: 'grid',
    styles: { font: 'helvetica', fontSize: 8.5, cellPadding: 2.2, lineColor: [200, 200, 200], lineWidth: 0.1 },
    headStyles: { fillColor: [4, 120, 87], textColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' },
    columnStyles: {
      0: { halign: 'center', cellWidth: 12 },
      1: { halign: 'center', cellWidth: 20 },
      2: { halign: 'left', cellWidth: 'auto' },
      3: { halign: 'center', cellWidth: 26 },
      4: { halign: 'right', cellWidth: 20, fontStyle: 'bold' },
    },
  });

  // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
  const finalY = (doc.lastAutoTable?.finalY || 160) + 10;
  let signatureY = finalY;
  if (signatureY > 230) {
    doc.addPage();
    signatureY = 25;
  }

  const signX = pageWidth - 75;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Sukatani, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, signX + 30, signatureY, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Camat Sukatani,', signX + 30, signatureY + 5, { align: 'center' });
  doc.text('Drs. H. AGUS DAHLAN, MM', signX + 30, signatureY + 28, { align: 'center' });
  doc.line(signX + 5, signatureY + 29, signX + 55, signatureY + 29);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('NIP. 197408171993111001', signX + 30, signatureY + 34, { align: 'center' });

  const cleanMonth = params.monthName.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Laporan_Rekapitulasi_Pelayanan_Sukatani_${cleanMonth}_${params.year}.pdf`;

  return { blob: doc.output('blob'), filename };
}

interface GenerateBukuRegisterPdfParams {
  seksiTitle: string;
  seksiName: string;
  records: Array<{
    nomorRegistrasi: string;
    tanggal: string;
    perihal?: string;
    namaPelayanan?: string;
    namaPemohon: string;
    nik?: string;
    namaDesa: string;
    alamat?: string;
    petugas: string;
  }>;
}

export function downloadBukuRegisterPDF({
  seksiTitle,
  seksiName,
  records,
}: GenerateBukuRegisterPdfParams): void {
  // Landscape A4 for Register Book
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // KOP SURAT
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 14, { align: 'center' });
  doc.setFontSize(14);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 20, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text('Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630', pageWidth / 2, 25, { align: 'center' });

  doc.setLineWidth(0.8);
  doc.line(14, 28, pageWidth - 14, 28);
  doc.setLineWidth(0.2);
  doc.line(14, 29.2, pageWidth - 14, 29.2);

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(seksiTitle.toUpperCase(), pageWidth / 2, 35, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Tahun Anggaran ${new Date().getFullYear()} — Seksi ${seksiName}`, pageWidth / 2, 40, { align: 'center' });

  const tableRows = records.map((r, idx) => [
    idx + 1,
    r.nomorRegistrasi,
    r.tanggal,
    r.perihal || r.namaPelayanan || '-',
    r.namaPemohon,
    r.nik || '-',
    r.namaDesa,
    r.petugas,
  ]);

  autoTable(doc, {
    startY: 44,
    head: [['No', 'Nomor Registrasi', 'Tanggal', 'Perihal / Pelayanan', 'Nama Pemohon', 'NIK', 'Desa', 'Petugas']],
    body: tableRows,
    theme: 'grid',
    styles: {
      font: 'helvetica',
      fontSize: 8,
      cellPadding: 2,
      lineColor: [180, 180, 180],
      lineWidth: 0.15,
      textColor: [30, 30, 30],
    },
    headStyles: {
      fillColor: [240, 243, 246],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { halign: 'center', cellWidth: 38, fontStyle: 'bold' },
      2: { halign: 'center', cellWidth: 22 },
      3: { halign: 'left', cellWidth: 'auto' },
      4: { halign: 'left', cellWidth: 40 },
      5: { halign: 'center', cellWidth: 34 },
      6: { halign: 'left', cellWidth: 26 },
      7: { halign: 'center', cellWidth: 22 },
    },
  });

  // Signature Block
  // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
  let signY = (doc.lastAutoTable?.finalY || 140) + 8;
  if (signY > 160) {
    doc.addPage();
    signY = 20;
  }

  const signX = pageWidth - 80;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Sukatani, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, signX + 30, signY, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Camat Sukatani,', signX + 30, signY + 4, { align: 'center' });
  doc.text('Drs. H. AGUS DAHLAN, MM', signX + 30, signY + 22, { align: 'center' });
  doc.line(signX + 5, signY + 23, signX + 55, signY + 23);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('NIP. 197408171993111001', signX + 30, signY + 27, { align: 'center' });

  const cleanSeksi = seksiName.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Buku_Register_${cleanSeksi}_Sukatani_${new Date().getFullYear()}.pdf`;
  doc.save(filename);
}

export interface GenerateBukuRegisterDesaPdfParams {
  desaTitle: string;
  desaFilterName: string;
  year: number;
  records: Array<{
    nomorRegistrasi: string;
    tanggal: string;
    perihal?: string;
    namaPelayanan?: string;
    namaPemohon: string;
    nik?: string;
    namaDesa: string;
    alamat?: string;
    seksi: string;
    petugas: string;
  }>;
}

export function downloadBukuRegisterDesaPDF({
  desaTitle,
  desaFilterName,
  year,
  records,
}: GenerateBukuRegisterDesaPdfParams): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // Kop Surat Resmi
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 14, { align: 'center' });
  doc.setFontSize(14);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 20, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text('Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630', pageWidth / 2, 25, { align: 'center' });

  doc.setLineWidth(0.8);
  doc.line(14, 28, pageWidth - 14, 28);
  doc.setLineWidth(0.2);
  doc.line(14, 29.2, pageWidth - 14, 29.2);

  // Judul Dokumen
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(desaTitle.toUpperCase(), pageWidth / 2, 35, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Tahun Anggaran ${year} — Wilayah Kecamatan Sukatani (${records.length} Berkas Pelayanan Terdaftar)`, pageWidth / 2, 40, { align: 'center' });

  const tableRows = records.map((r, idx) => [
    idx + 1,
    r.nomorRegistrasi,
    r.tanggal,
    r.perihal || r.namaPelayanan || '-',
    r.namaPemohon,
    r.nik || '-',
    r.namaDesa,
    r.alamat || '-',
    r.seksi,
    r.petugas,
  ]);

  autoTable(doc, {
    startY: 44,
    head: [['No', 'No. Registrasi', 'Tanggal', 'Perihal Pelayanan', 'Nama Pemohon', 'NIK', 'Desa', 'Alamat', 'Seksi', 'Petugas']],
    body: tableRows,
    theme: 'grid',
    styles: {
      font: 'helvetica',
      fontSize: 7.5,
      cellPadding: 2,
      lineColor: [180, 180, 180],
      lineWidth: 0.15,
      textColor: [30, 30, 30],
    },
    headStyles: {
      fillColor: [240, 243, 246],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { halign: 'center', cellWidth: 34, fontStyle: 'bold' },
      2: { halign: 'center', cellWidth: 20 },
      3: { halign: 'left', cellWidth: 'auto' },
      4: { halign: 'left', cellWidth: 32 },
      5: { halign: 'center', cellWidth: 30 },
      6: { halign: 'left', cellWidth: 22 },
      7: { halign: 'left', cellWidth: 26 },
      8: { halign: 'center', cellWidth: 20 },
      9: { halign: 'center', cellWidth: 18 },
    },
  });

  // Tanda Tangan Camat Sukatani
  // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
  let signY = (doc.lastAutoTable?.finalY || 140) + 8;
  if (signY > 160) {
    doc.addPage();
    signY = 20;
  }

  const signX = pageWidth - 80;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Sukatani, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, signX + 30, signY, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Camat Sukatani,', signX + 30, signY + 4, { align: 'center' });
  doc.text('Drs. H. AGUS DAHLAN, MM', signX + 30, signY + 22, { align: 'center' });
  doc.line(signX + 5, signY + 23, signX + 55, signY + 23);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('NIP. 197408171993111001', signX + 30, signY + 27, { align: 'center' });

  const cleanDesa = desaFilterName.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Buku_Register_Pelayanan_${cleanDesa}_Sukatani_${year}.pdf`;
  doc.save(filename);
}

export function generateBukuRegisterDesaPDFBlob({
  desaTitle,
  desaFilterName,
  year,
  records,
}: GenerateBukuRegisterDesaPdfParams): { blob: Blob; filename: string } {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 14, { align: 'center' });
  doc.setFontSize(14);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 20, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text('Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630', pageWidth / 2, 25, { align: 'center' });

  doc.setLineWidth(0.8);
  doc.line(14, 28, pageWidth - 14, 28);
  doc.setLineWidth(0.2);
  doc.line(14, 29.2, pageWidth - 14, 29.2);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(desaTitle.toUpperCase(), pageWidth / 2, 35, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Tahun Anggaran ${year} — Wilayah Kecamatan Sukatani (${records.length} Berkas Pelayanan Terdaftar)`, pageWidth / 2, 40, { align: 'center' });

  const tableRows = records.map((r, idx) => [
    idx + 1,
    r.nomorRegistrasi,
    r.tanggal,
    r.perihal || r.namaPelayanan || '-',
    r.namaPemohon,
    r.nik || '-',
    r.namaDesa,
    r.alamat || '-',
    r.seksi,
    r.petugas,
  ]);

  autoTable(doc, {
    startY: 44,
    head: [['No', 'No. Registrasi', 'Tanggal', 'Perihal Pelayanan', 'Nama Pemohon', 'NIK', 'Desa', 'Alamat', 'Seksi', 'Petugas']],
    body: tableRows,
    theme: 'grid',
    styles: {
      font: 'helvetica',
      fontSize: 7.5,
      cellPadding: 2,
      lineColor: [180, 180, 180],
      lineWidth: 0.15,
      textColor: [30, 30, 30],
    },
    headStyles: {
      fillColor: [240, 243, 246],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { halign: 'center', cellWidth: 34, fontStyle: 'bold' },
      2: { halign: 'center', cellWidth: 20 },
      3: { halign: 'left', cellWidth: 'auto' },
      4: { halign: 'left', cellWidth: 32 },
      5: { halign: 'center', cellWidth: 30 },
      6: { halign: 'left', cellWidth: 22 },
      7: { halign: 'left', cellWidth: 26 },
      8: { halign: 'center', cellWidth: 20 },
      9: { halign: 'center', cellWidth: 18 },
    },
  });

  // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
  let signY = (doc.lastAutoTable?.finalY || 140) + 8;
  if (signY > 160) {
    doc.addPage();
    signY = 20;
  }

  const signX = pageWidth - 80;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Sukatani, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, signX + 30, signY, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Camat Sukatani,', signX + 30, signY + 4, { align: 'center' });
  doc.text('Drs. H. AGUS DAHLAN, MM', signX + 30, signY + 22, { align: 'center' });
  doc.line(signX + 5, signY + 23, signX + 55, signY + 23);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('NIP. 197408171993111001', signX + 30, signY + 27, { align: 'center' });

  const cleanDesa = desaFilterName.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Buku_Register_Pelayanan_${cleanDesa}_Sukatani_${year}.pdf`;

  return { blob: doc.output('blob'), filename };
}

/**
 * Downloads self-contained HTML document with letterhead, print CSS and auto-print trigger
 */
export function downloadHTMLDocument(filename: string, contentHtml: string): void {
  const fullHtml = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>${filename.replace('.html', '')}</title>
  <style>
    @page { size: A4; margin: 15mm 15mm 15mm 15mm; }
    body { font-family: Arial, Helvetica, sans-serif; color: #1e293b; margin: 0; padding: 20px; font-size: 11pt; }
    .letterhead { text-align: center; border-bottom: 3px double #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .letterhead h2 { margin: 0; font-size: 13pt; text-transform: uppercase; font-weight: bold; letter-spacing: 0.5px; }
    .letterhead h1 { margin: 4px 0; font-size: 18pt; text-transform: uppercase; font-weight: 800; color: #047857; }
    .letterhead p { margin: 2px 0; font-size: 9pt; color: #475569; }
    .title { text-align: center; margin: 18px 0; }
    .title h3 { margin: 0; font-size: 12pt; text-decoration: underline; text-transform: uppercase; font-weight: bold; }
    .title p { margin: 4px 0 0 0; font-size: 9.5pt; color: #475569; }
    table { width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 9.5pt; }
    th, td { border: 1px solid #cbd5e1; padding: 6px 8px; }
    th { background-color: #f1f5f9; font-weight: bold; text-align: center; }
    .subtotal-row { background-color: #f8fafc; font-weight: bold; }
    .total-row { background-color: #e2e8f0; font-weight: bold; }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .signature { margin-top: 40px; display: flex; justify-content: flex-end; }
    .sign-box { width: 260px; text-align: center; font-size: 9.5pt; float: right; }
    @media print {
      body { padding: 0; }
      .no-print { display: none !important; }
    }
  </style>
</head>
<body>
  ${contentHtml}
</body>
</html>`;

  const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Downloads official A4 Tanda Bukti Serah Terima Dokumen (Pendaftaran PATEN) as PDF
 */
export function downloadBuktiSerahTerimaPDF(record: PelayananRecord): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // 1. KOP SURAT RESMI
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 16, { align: 'center' });
  doc.setFontSize(15);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 23, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(
    'Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630',
    pageWidth / 2,
    28,
    { align: 'center' }
  );
  doc.text(
    'Laman Resmi: kecamatansukatani.bekasikab.go.id | Pos-el: kecamatan.sukatani@bekasikab.go.id',
    pageWidth / 2,
    32,
    { align: 'center' }
  );

  // Double horizontal rule
  doc.setLineWidth(0.8);
  doc.line(14, 35, pageWidth - 14, 35);
  doc.setLineWidth(0.2);
  doc.line(14, 36.2, pageWidth - 14, 36.2);

  // 2. JUDUL TANDA BUKTI SERAH TERIMA
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('TANDA BUKTI PENDAFTARAN & SERAH TERIMA DOKUMEN', pageWidth / 2, 43, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('PELAYANAN ADMINISTRASI TERPADU KECAMATAN (PATEN)', pageWidth / 2, 48, { align: 'center' });

  // Highlight Box Nomor Registrasi
  doc.setFillColor(240, 253, 244); // light emerald-50
  doc.setDrawColor(16, 185, 129); // emerald-500
  doc.setLineWidth(0.4);
  doc.roundedRect(14, 52, pageWidth - 28, 14, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(6, 78, 59);
  doc.text('NOMOR REGISTRASI :', 20, 60.5);
  doc.setFontSize(12);
  doc.setFont('courier', 'bold');
  doc.text(record.nomorRegistrasi, 75, 61);
  doc.setTextColor(0, 0, 0);

  // 3. TABLE / FORM RINCIAN
  const tableData = [
    ['Tanggal Registrasi', `: ${record.tanggal}`],
    ['Seksi Pelayanan', `: Seksi ${record.seksi}`],
    ['Jenis Pelayanan', `: ${record.namaPelayanan}`],
    ['Perihal / Keperluan', `: ${record.perihal || record.namaPelayanan}`],
    ['Nama Lengkap Pemohon', `: ${record.namaPemohon}`],
    ['NIK (No. KTP)', `: ${record.nik || '-'}`],
    ['Desa Asal', `: Desa ${record.namaDesa}`],
    ['Alamat / Kp / RT / RW', `: ${record.alamat || '-'}`],
    ['Keterangan / Berkas', `: ${record.keterangan || 'Persyaratan berkas diterima lengkap'}`],
    ...(record.linkGoogleDrive ? [['Upload Dokumen (Google Drive)', `: ${record.linkGoogleDrive}`]] : []),
    ['Petugas Penerima Loket', `: ${record.petugas}`],
  ];

  autoTable(doc, {
    startY: 70,
    body: tableData,
    theme: 'plain',
    styles: {
      font: 'helvetica',
      fontSize: 9,
      cellPadding: 2.2,
      textColor: [30, 41, 59],
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 55 },
      1: { fontStyle: 'normal' },
    },
  });

  const finalY = (doc as any).lastAutoTable ? (doc as any).lastAutoTable.finalY : 135;

  // 4. KLAUSUL KETENTUAN PENGAMBILAN DOKUMEN
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(14, finalY + 6, pageWidth - 28, 25, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text('KETENTUAN & INFORMASI PENGAMBILAN DOKUMEN:', 18, finalY + 12);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(
    '1. Tanda bukti ini adalah bukti sah berkas permohonan telah diterima di loket PATEN Kecamatan Sukatani.',
    18,
    finalY + 17
  );
  doc.text(
    '2. Harap simpan tanda bukti ini dan tunjukkan kepada petugas saat pengambilan dokumen yang telah selesai/dilegalisasi.',
    18,
    finalY + 22
  );
  doc.text(
    '3. Untuk memeriksa perkembangan status berkas, sebutkan Nomor Registrasi yang tertera di atas.',
    18,
    finalY + 27
  );
  doc.setTextColor(0, 0, 0);

  // 5. TANDA TANGAN SERAH TERIMA DUA PIHAK
  const signY = finalY + 41;
  const todayStr = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Sukatani, ${todayStr}`, pageWidth - 55, signY - 6, { align: 'center' });

  // Kiri: Pemohon
  doc.text('Yang Menyerahkan (Pemohon),', 50, signY, { align: 'center' });
  doc.text('( ................................................ )', 50, signY + 24, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text(record.namaPemohon, 50, signY + 29, { align: 'center' });

  // Kanan: Petugas
  doc.setFont('helvetica', 'normal');
  doc.text('Yang Menerima (Petugas PATEN),', pageWidth - 55, signY, { align: 'center' });
  doc.text('( ................................................ )', pageWidth - 55, signY + 24, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text(record.petugas, pageWidth - 55, signY + 29, { align: 'center' });

  const cleanNoReg = record.nomorRegistrasi.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Bukti_Serah_Terima_PATEN_${cleanNoReg}.pdf`;
  doc.save(filename);
}

export interface GenerateLaporanRekapPdfParams {
  filterTitle: string;
  startDate?: string;
  endDate?: string;
  records: PelayananRecord[];
}

export function downloadLaporanRekapitulasiPDF({
  filterTitle,
  startDate,
  endDate,
  records,
}: GenerateLaporanRekapPdfParams): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // KOP SURAT
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('PEMERINTAH KABUPATEN BEKASI', pageWidth / 2, 14, { align: 'center' });
  doc.setFontSize(14);
  doc.text('KECAMATAN SUKATANI', pageWidth / 2, 20, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text('Jl. Raya Sukatani No. 1, Sukatani, Kabupaten Bekasi, Jawa Barat 17630', pageWidth / 2, 25, { align: 'center' });
  doc.text('Laman Resmi: kecamatansukatani.bekasikab.go.id | Email: kecamatan.sukatani@bekasikab.go.id', pageWidth / 2, 29, { align: 'center' });

  doc.setLineWidth(0.8);
  doc.line(14, 32, pageWidth - 14, 32);
  doc.setLineWidth(0.2);
  doc.line(14, 33.2, pageWidth - 14, 33.2);

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(`LAPORAN REKAPITULASI PELAYANAN — ${filterTitle.toUpperCase()}`, pageWidth / 2, 40, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  const periodeStr = (startDate && endDate) ? `Periode: ${startDate} s/d ${endDate}` : `Total ${records.length} Berkas Teregistrasi`;
  doc.text(`${periodeStr} — Wilayah Kerja Kecamatan Sukatani`, pageWidth / 2, 45, { align: 'center' });

  const tableRows = records.map((r, idx) => [
    idx + 1,
    r.tanggal,
    r.nomorRegistrasi,
    r.perihal || r.namaPelayanan,
    r.namaPemohon,
    r.nik || '-',
    r.namaDesa,
    r.seksi,
    r.petugas,
  ]);

  autoTable(doc, {
    startY: 49,
    head: [['No', 'Tanggal', 'No. Registrasi', 'Perihal Permohonan', 'Nama Pemohon', 'NIK', 'Desa', 'Seksi', 'Petugas']],
    body: tableRows,
    theme: 'grid',
    styles: {
      font: 'helvetica',
      fontSize: 7.5,
      cellPadding: 2,
      lineColor: [200, 200, 200],
      lineWidth: 0.1,
      textColor: [30, 30, 30],
    },
    headStyles: {
      fillColor: [4, 120, 87],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { halign: 'center', cellWidth: 20 },
      2: { halign: 'center', cellWidth: 38, fontStyle: 'bold' },
      3: { halign: 'left', cellWidth: 'auto' },
      4: { halign: 'left', cellWidth: 35, fontStyle: 'bold' },
      5: { halign: 'center', cellWidth: 28 },
      6: { halign: 'center', cellWidth: 24 },
      7: { halign: 'center', cellWidth: 20 },
      8: { halign: 'center', cellWidth: 22 },
    },
  });

  // Tanda Tangan Camat
  // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
  let signY = (doc.lastAutoTable?.finalY || 140) + 8;
  if (signY > 160) {
    doc.addPage();
    signY = 20;
  }

  const signX = pageWidth - 75;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Sukatani, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, signX + 25, signY, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.text('Camat Sukatani,', signX + 25, signY + 4, { align: 'center' });
  doc.text('Drs. H. AGUS DAHLAN, MM', signX + 25, signY + 22, { align: 'center' });
  doc.line(signX + 2, signY + 23, signX + 48, signY + 23);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('NIP. 197408171993111001', signX + 25, signY + 27, { align: 'center' });

  const cleanFilter = filterTitle.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Laporan_Rekap_${cleanFilter}_${startDate || 'All'}_${endDate || 'All'}.pdf`;
  doc.save(filename);
}

