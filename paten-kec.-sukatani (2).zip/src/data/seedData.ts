import { UserProfile, Desa, JenisPelayanan, PelayananRecord } from '../types';

export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'user-1',
    name: 'Budi Santoso',
    username: 'Admin',
    email: 'admin@sukatani.go.id',
    password: 'Admin123',
    level: 'L1',
    status: 'Aktif',
  },
  {
    id: 'user-2',
    name: 'Siti Aminah',
    username: 'Pelayanan',
    email: 'yanlik@sukatani.go.id',
    password: 'Yanlik123',
    level: 'L2',
    seksi: 'Yanlik',
    status: 'Aktif',
  },
  {
    id: 'user-3',
    name: 'Andi Wijaya',
    username: 'Pemerintahan',
    email: 'tapem@sukatani.go.id',
    password: 'Tapem123',
    level: 'L3',
    seksi: 'Pemerintahan',
    status: 'Aktif',
  },
  {
    id: 'user-4',
    name: 'Rina Susanti',
    username: 'Ekbang',
    email: 'ekbang@sukatani.go.id',
    password: 'Ekbang123',
    level: 'L4',
    seksi: 'Ekbang',
    status: 'Aktif',
  },
  {
    id: 'user-5',
    name: 'Hendra Gunawan',
    username: 'PMD',
    email: 'pmd@sukatani.go.id',
    password: 'PMD123',
    level: 'L5',
    seksi: 'PMD',
    status: 'Aktif',
  },
  {
    id: 'user-6',
    name: 'Agus Setiawan',
    username: 'Trantib',
    email: 'trantib@sukatani.go.id',
    password: 'Trantib123',
    level: 'L6',
    seksi: 'Trantib',
    status: 'Aktif',
  },
];

export const INITIAL_DESA: Desa[] = [
  { id: 'desa-1', kodeDesa: '32.16.14.2001', namaDesa: 'Sukamulya' },
  { id: 'desa-2', kodeDesa: '32.16.14.2002', namaDesa: 'Sukadarma' },
  { id: 'desa-3', kodeDesa: '32.16.14.2003', namaDesa: 'Sukamanah' },
  { id: 'desa-4', kodeDesa: '32.16.14.2004', namaDesa: 'Sukarukun' },
  { id: 'desa-5', kodeDesa: '32.16.14.2005', namaDesa: 'Sukahurip' },
  { id: 'desa-6', kodeDesa: '32.16.14.2006', namaDesa: 'Sukaasih' },
  { id: 'desa-7', kodeDesa: '32.16.14.2007', namaDesa: 'Banjarsari' },
];

export const INITIAL_JENIS_PELAYANAN: JenisPelayanan[] = [
  // 1. Seksi Pelayanan Publik (Yanlik) - Level 1 & Level 2
  {
    id: 'jp-ynl-01',
    kode: 'YNL-01',
    namaPelayanan: 'Surat Keterangan Belum Pernah Menikah',
    seksi: 'Yanlik',
    formatKodeRegistrasi: '470.1/No/Bln/Thn',
  },
  {
    id: 'jp-ynl-02',
    kode: 'YNL-02',
    namaPelayanan: 'Surat Keterangan Belum Punya Anak',
    seksi: 'Yanlik',
    formatKodeRegistrasi: '470.2/No/Bln/Thn',
  },
  {
    id: 'jp-ynl-03a',
    kode: 'YNL-03A',
    namaPelayanan: 'Surat Keterangan Tidak Mampu (SKTM) - Pengantar Jamkesda',
    seksi: 'Yanlik',
    formatKodeRegistrasi: '400.7.3.1/No/Bln/Thn',
  },
  {
    id: 'jp-ynl-03b',
    kode: 'YNL-03B',
    namaPelayanan: 'Surat Keterangan Tidak Mampu (SKTM) - Pengantar KIS',
    seksi: 'Yanlik',
    formatKodeRegistrasi: '400.7.3.2/No/Bln/Thn',
  },
  {
    id: 'jp-ynl-03c',
    kode: 'YNL-03C',
    namaPelayanan: 'Surat Keterangan Tidak Mampu (SKTM) - Pengantar KIP',
    seksi: 'Yanlik',
    formatKodeRegistrasi: '400.7.3.3/No/Bln/Thn',
  },
  {
    id: 'jp-ynl-03d',
    kode: 'YNL-03D',
    namaPelayanan: 'Surat Keterangan Tidak Mampu (SKTM) - Pengantar Lainnya',
    seksi: 'Yanlik',
    formatKodeRegistrasi: '400.7.3.4/No/Bln/Thn',
  },

  // 2. Seksi Pemerintahan - Level 1 & Level 3
  {
    id: 'jp-pmr-01',
    kode: 'PMR-01',
    namaPelayanan: 'Registrasi Pernyataan Ahli Waris',
    seksi: 'Pemerintahan',
    formatKodeRegistrasi: '470.4/No/Bln/Thn',
  },
  {
    id: 'jp-pmr-02',
    kode: 'PMR-02',
    namaPelayanan: 'Legalisasi Keterangan Ahli Waris WNI',
    seksi: 'Pemerintahan',
    formatKodeRegistrasi: '470.5/No/Bln/Thn',
  },
  {
    id: 'jp-pmr-03',
    kode: 'PMR-03',
    namaPelayanan: 'Akta Jual Beli Tanah',
    seksi: 'Pemerintahan',
    formatKodeRegistrasi: '593.1/No/Bln/Thn',
  },
  {
    id: 'jp-pmr-04',
    kode: 'PMR-04',
    namaPelayanan: 'Akta Jual Beli Tanah Waris',
    seksi: 'Pemerintahan',
    formatKodeRegistrasi: '593.2/No/Bln/Thn',
  },
  {
    id: 'jp-pmr-05',
    kode: 'PMR-05',
    namaPelayanan: 'Akta Pembagian Hak Bersama (APHB)',
    seksi: 'Pemerintahan',
    formatKodeRegistrasi: '593.3/No/Bln/Thn',
  },

  // 3. Seksi Ekonomi & Pembangunan (Ekbang) - Level 1 & Level 4
  {
    id: 'jp-ekb-01',
    kode: 'EKB-01',
    namaPelayanan: 'Rekomendasi Persetujuan Bangunan Gedung (PBG)',
    seksi: 'Ekbang',
    formatKodeRegistrasi: '640/No/Bln/Thn',
  },
  {
    id: 'jp-ekb-02',
    kode: 'EKB-02',
    namaPelayanan: 'Rekomendasi Pengajuan IMB Perumahan',
    seksi: 'Ekbang',
    formatKodeRegistrasi: '648/No/Bln/Thn',
  },
  {
    id: 'jp-ekb-03',
    kode: 'EKB-03',
    namaPelayanan: 'Rekomendasi Persetujuan Bangunan Tower',
    seksi: 'Ekbang',
    formatKodeRegistrasi: '649/No/Bln/Thn',
  },

  // 4. Seksi Pemberdayaan Masyarakat & Desa (PMD) - Level 1 & Level 5
  {
    id: 'jp-pmd-01',
    kode: 'PMD-01',
    namaPelayanan: 'Legalisasi Proposal Bantuan Hibah',
    seksi: 'PMD',
    formatKodeRegistrasi: '140.1/No/Bln/Thn',
  },
  {
    id: 'jp-pmd-02',
    kode: 'PMD-02',
    namaPelayanan: 'Surat Keterangan Domisili Haji',
    seksi: 'PMD',
    formatKodeRegistrasi: '451.1/No/Bln/Thn',
  },
  {
    id: 'jp-pmd-03',
    kode: 'PMD-03',
    namaPelayanan: 'Rekomendasi Pendirian PAUD/TK/SD/SMP/SMK',
    seksi: 'PMD',
    formatKodeRegistrasi: '421.1/No/Bln/Thn',
  },

  // 5. Seksi Ketenteraman & Ketertiban (Trantib) - Level 1 & Level 6
  {
    id: 'jp-trt-01',
    kode: 'TRT-01',
    namaPelayanan: 'Surat Izin Keramaian',
    seksi: 'Trantib',
    formatKodeRegistrasi: '300.1/No/Bln/Thn',
  },
  {
    id: 'jp-trt-02',
    kode: 'TRT-02',
    namaPelayanan: 'Legalisasi Surat Keterangan SKCK',
    seksi: 'Trantib',
    formatKodeRegistrasi: '331.1/No/Bln/Thn',
  },
  {
    id: 'jp-trt-03',
    kode: 'TRT-03',
    namaPelayanan: 'Legalisasi Surat Keterangan Pendaftaran TNI/POLRI',
    seksi: 'Trantib',
    formatKodeRegistrasi: '331.2/No/Bln/Thn',
  },
  {
    id: 'jp-trt-04',
    kode: 'TRT-04',
    namaPelayanan: 'Permohonan Pemasangan Spanduk / Umbul-Umbul',
    seksi: 'Trantib',
    formatKodeRegistrasi: '300.3/No/Bln/Thn',
  },
];

// Helper to convert month index (1-12) to Roman numeral
export function toRomanNumeral(monthNum: number): string {
  const romanMap: Record<number, string> = {
    1: 'I',
    2: 'II',
    3: 'III',
    4: 'IV',
    5: 'V',
    6: 'VI',
    7: 'VII',
    8: 'VIII',
    9: 'IX',
    10: 'X',
    11: 'XI',
    12: 'XII',
  };
  return romanMap[monthNum] || 'IX';
}

// Pre-seeded records - empty for production / clean state:
export const INITIAL_PELAYANAN_RECORDS: PelayananRecord[] = [];
